"""App configuration for the Promotions module."""

from django.apps import AppConfig


class PromotionsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.promotions"
    label = "promotions"
    verbose_name = "Promotions"
