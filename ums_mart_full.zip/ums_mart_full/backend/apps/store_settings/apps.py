"""App configuration for the Store Settings module."""

from django.apps import AppConfig


class StoreSettingsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.store_settings"
    label = "store_settings"
    verbose_name = "Store Settings"
