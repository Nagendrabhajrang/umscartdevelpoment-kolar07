// Thin, read-only models over the JSON the Django API already returns.
// No code generation, no rigid typing of optional fields that the admin can
// add to: a missing key reads as null and the UI degrades.

import '../core/config.dart';

double _d(dynamic v) {
  if (v == null) return 0;
  if (v is num) return v.toDouble();
  return double.tryParse('$v') ?? 0;
}

int _i(dynamic v) {
  if (v == null) return 0;
  if (v is int) return v;
  if (v is num) return v.toInt();
  return int.tryParse('$v') ?? 0;
}

String _s(dynamic v, [String fallback = '']) =>
    v == null ? fallback : '$v';

/// Absolute-ise a media path returned by the API.
///
/// In relative mode the value stays a path so the browser/device asks the same
/// origin that served the app (and its proxy forwards /media to Django).
String _media(dynamic v) {
  final raw = _s(v);
  if (raw.isEmpty) return raw;
  if (raw.startsWith('http')) return raw;
  if (ApiConfig.isRelative) {
    // Flutter web needs an absolute URI even for a same-origin path, so resolve
    // it against the page the app was served from.
    return Uri.base.resolve(raw).toString();
  }
  return '${ApiConfig.baseUrl}$raw';
}

class Category {
  Category(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  String get name => _s(json['name'], 'Category');
  String get imageUrl => _media(json['image_url'] ?? json['image']);
  String get iconName => _s(json['icon_name']);
  int get parentId => _i(json['parent']);
  bool get isFeatured => json['is_featured'] == true;
  int get productCount => _i(json['product_count']);
}

class Product {
  Product(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  String get name => _s(json['name'], 'Product');
  String get brand => _s(json['brand']);
  String get unitLabel => _s(json['unit_label']);
  double get mrp => _d(json['mrp']);
  double get price => _d(json['selling_price']);
  double get discount => _d(json['discount_percent']);
  String get imageUrl => _media(json['image_url'] ?? json['primary_image']);
  bool get inStock => json['in_stock'] != false;
  int get available => _i(json['available_quantity']);
  bool get isVeg => json['is_vegetarian'] != false;
  bool get isFeatured => json['is_featured'] == true;
  String get categoryName => _s(json['category_name']);
  int get categoryId => _i(json['category']);
  int get maxOrderQty => _i(json['max_order_quantity']) == 0
      ? 20
      : _i(json['max_order_quantity']);
}

class CartLine {
  CartLine(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  int get productId => _i(json['product']);
  String get name => _s(json['product_name'], 'Item');
  String get unitLabel => _s(json['unit_label']);
  String get imageUrl => _media(json['product_image']);
  int get quantity => _i(json['quantity']);
  double get unitPrice => _d(json['unit_price']);
  double get lineTotal => _d(json['line_total']);
  double get lineSavings => _d(json['line_savings']);
  bool get isAvailable => json['is_available'] != false;
}

class Cart {
  Cart(this.json);
  final Map<String, dynamic> json;

  static Cart empty() => Cart(const {});

  List<CartLine> get lines =>
      ((json['items'] as List?) ?? const [])
          .whereType<Map>()
          .map((e) => CartLine(Map<String, dynamic>.from(e)))
          .toList();

  int get itemCount => _i(json['item_count']);
  int get totalQuantity => _i(json['total_quantity']);
  double get subtotal => _d(json['subtotal']);
  double get mrpTotal => _d(json['mrp_total']);
  double get savings => _d(json['savings']);
  String? get couponCode =>
      (json['coupon_code'] ?? '') == '' ? null : _s(json['coupon_code']);
  bool get isEmpty => lines.isEmpty;
}

class CartSummary {
  CartSummary(this.json);
  final Map<String, dynamic> json;

  double get subtotal => _d(json['subtotal']);
  double get mrpTotal => _d(json['mrp_total']);
  double get savings => _d(json['savings'] ?? json['product_savings']);
  double get discount => _d(json['discount_amount']);
  double get delivery => _d(json['delivery_charge']);
  double get packaging => _d(json['packaging_charge']);
  double get tax => _d(json['tax_amount']);
  double get grandTotal => _d(json['grand_total']);
  int get itemCount => _i(json['item_count']);
  String? get couponCode =>
      (json['coupon_code'] ?? '') == '' ? null : _s(json['coupon_code']);
  List<String> get issues =>
      ((json['issues'] as List?) ?? const []).map((e) => '$e').toList();
}

class BannerItem {
  BannerItem(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  String get title => _s(json['title']);
  String get subtitle => _s(json['subtitle']);
  String get imageUrl => _media(json['image_url'] ?? json['image']);
  String get mobileImageUrl => _media(json['mobile_image_url'] ?? json['mobile_image']);
  String get placement => _s(json['placement'], 'hero');
  String get linkType => _s(json['link_type']);
  String get linkUrl => _s(json['link_url'] ?? json['resolved_link']);
  int get linkedProduct => _i(json['linked_product']);
  int get linkedCategory => _i(json['linked_category']);
}

class StoreSettings {
  StoreSettings(this.json);
  final Map<String, dynamic> json;

  String get name => _s(json['store_name'], 'UMS Mart');
  String get tagline => _s(json['tagline'], 'Fresh groceries to your door');
  String get phone => _s(json['contact_phone']);
  String get email => _s(json['contact_email']);
  String get address => _s(json['address']);
  String get currencySymbol => _s(json['currency_symbol'], '₹');
  double get deliveryCharge => _d(json['delivery_charge']);
  double get freeDeliveryAbove => _d(json['free_delivery_threshold']);
  double get minimumOrder => _d(json['minimum_order_value']);
  int get etaMinutes => _i(json['delivery_eta_minutes']);
  bool get codEnabled => json['cod_enabled'] != false;
  bool get storeOpen => json['is_store_open'] != false;
  String get maintenanceMessage => _s(json['maintenance_message']);
  int get maxItemsPerOrder => _i(json['max_items_per_order']);
}

class Address {
  Address(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  String get label => _s(json['label'], 'Home');
  String get recipient => _s(json['recipient_name']);
  String get mobile => _s(json['recipient_mobile']);
  String get line1 => _s(json['landmark']);
  String get city => _s(json['city']);
  String get state => _s(json['state']);
  String get pincode => _s(json['pincode']);
  bool get isDefault => json['is_default'] == true;

  String get oneLine => [line1, city, state, pincode]
      .where((e) => e.isNotEmpty)
      .join(', ');
}

class OrderSummary {
  OrderSummary(this.json);
  final Map<String, dynamic> json;

  int get id => _i(json['id']);
  String get number => _s(json['order_number'], 'Order');
  String get status => _s(json['status'], 'pending');
  String get paymentStatus => _s(json['payment_status'], 'pending');
  String get paymentMethod => _s(json['payment_method'], 'cod');
  double get total => _d(json['grand_total']);
  int get itemCount => _i(json['item_count']);
  String get createdAt => _s(json['created_at']);
  String get etaMinutes => _s(json['delivery_eta_minutes']);
  String get deliveryCity => _s(json['delivery_city']);
  List<dynamic> get items => (json['items'] as List?) ?? const [];
  List<dynamic> get history => (json['status_history'] as List?) ?? const [];
  String get cancellationReason => _s(json['cancellation_reason']);

  String get statusLabel {
    const labels = {
      'pending': 'Placed',
      'confirmed': 'Confirmed',
      'processing': 'Packing',
      'out_for_delivery': 'Out for delivery',
      'delivered': 'Delivered',
      'cancelled': 'Cancelled',
    };
    return labels[status] ?? status;
  }

  String get paymentLabel {
    const labels = {
      'pending': 'Payment pending',
      'paid': 'Paid',
      'cod_due': 'Pay on delivery',
      'cod_collected': 'Cash collected',
      'failed': 'Payment failed',
      'refunded': 'Refunded',
      'partially_refunded': 'Partly refunded',
    };
    final known = labels[paymentStatus];
    if (known != null) return known;
    // Never leak a raw enum value such as "cod_due" into the UI.
    final words = paymentStatus.replaceAll('_', ' ').trim();
    if (words.isEmpty) return '';
    return words[0].toUpperCase() + words.substring(1);
  }
}

class CustomerAccount {
  CustomerAccount(this.json);
  final Map<String, dynamic> json;

  Map<String, dynamic> get user {
    final u = json['user'] ?? json['customer'] ?? json;
    return u is Map ? Map<String, dynamic>.from(u) : <String, dynamic>{};
  }

  int get id => _i(user['id'] ?? json['user_id']);
  String get name => _s(user['full_name'] ?? user['display_name'] ?? user['name'],
      'Shopper');
  String get mobile => _s(user['mobile_number'] ?? user['mobile']);
  String get email => _s(user['email']);
}
