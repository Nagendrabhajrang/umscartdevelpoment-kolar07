import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/api_client.dart';
import '../core/services.dart';
import '../models/models.dart';
import 'auth_state.dart';

/// The basket.
///
/// Guest support mirrors the web app: an anonymous shopper gets a key stored on
/// the device, the server keeps a cart against it, and the key travels in the
/// `X-Guest-Cart` header (and in the login body) so the basket survives signing
/// in. One basket, whether or not you are logged in.
class CartState extends ChangeNotifier {
  CartState(this._auth);

  final AuthState _auth;

  static const String _guestKeyPref = 'ums.guestCartKey';

  Cart _cart = Cart.empty();
  CartSummary? _summary;
  bool _loading = false;

  Cart get cart => _cart;
  CartSummary? get summary => _summary;
  bool get loading => _loading;
  int get count => _cart.totalQuantity;
  bool get isEmpty => _cart.isEmpty;
  double get subtotal => _cart.subtotal;
  double get savings => _cart.savings;

  /// Load the guest key off the device and fetch the basket.
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    var key = prefs.getString(_guestKeyPref);
    if (key == null) {
      key = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
      await prefs.setString(_guestKeyPref, key);
    }
    // Only a guest needs the header; the server ignores it when a session
    // exists, and ApiClient drops it after a successful merge.
    if (!_auth.isSignedIn) {
      ApiClient.instance.guestKey = key;
    }
    await refresh();
  }

  Future<void> refresh() async {
    _loading = true;
    notifyListeners();
    try {
      _cart = await CartService.get();
      try {
        _summary = await CartService.summary();
      } catch (_) {
        _summary = null;
      }
    } catch (_) {
      // Keep whatever we had; a failed refresh is not an empty cart.
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> add(Product product, {int quantity = 1}) async {
    await CartService.add(product, quantity: quantity);
    await refresh();
  }

  Future<void> setQuantity(int itemId, int quantity) async {
    if (quantity <= 0) {
      await CartService.remove(itemId);
    } else {
      await CartService.setQuantity(itemId, quantity);
    }
    await refresh();
  }

  Future<void> remove(int itemId) async {
    await CartService.remove(itemId);
    await refresh();
  }

  Future<void> applyCoupon(String code) async {
    await CartService.applyCoupon(code);
    await refresh();
  }

  Future<void> removeCoupon() async {
    await CartService.removeCoupon();
    await refresh();
  }

  int quantityOf(int productId) {
    for (final line in _cart.lines) {
      if (line.productId == productId) return line.quantity;
    }
    return 0;
  }
}
