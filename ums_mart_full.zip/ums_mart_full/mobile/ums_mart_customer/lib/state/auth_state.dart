import 'package:flutter/foundation.dart';

import '../core/api_client.dart';
import '../core/services.dart';
import '../models/models.dart';

/// The customer session.
///
/// Round-30 parity with the web app: the credential is an HttpOnly cookie held
/// by the cookie jar, so "am I signed in?" is a question only the server can
/// answer. A 401 is the only thing allowed to clear the local profile.
class AuthState extends ChangeNotifier {
  CustomerAccount? _account;
  bool _busy = false;
  String? _pendingMobile;
  String? _devOtp;

  CustomerAccount? get account => _account;
  bool get isSignedIn => _account != null;
  bool get busy => _busy;
  String? get devOtp => _devOtp;
  String? get pendingMobile => _pendingMobile;

  void setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  /// Called once at boot: confirms the cookie session with the server.
  Future<void> restore() async {
    try {
      _account = await AuthService.session();
    } catch (_) {
      // A network failure must not sign anybody out - we simply do not know.
      _account = null;
    }
    notifyListeners();
  }

  /// Step 1. Returns the dev OTP when the backend is in AUTH_DEV_MODE.
  Future<String?> sendOtp(String mobile) async {
    setBusy(true);
    try {
      final payload = await AuthService.sendOtp(mobile.trim());
      _pendingMobile = mobile.trim();
      _devOtp = payload['dev_otp']?.toString();
      return _devOtp;
    } finally {
      setBusy(false);
    }
  }

  Future<String?> resendOtp() async {
    final mobile = _pendingMobile;
    if (mobile == null) return null;
    setBusy(true);
    try {
      final payload = await AuthService.resendOtp(mobile);
      _devOtp = payload['dev_otp']?.toString();
      return _devOtp;
    } finally {
      setBusy(false);
    }
  }

  /// Step 2. The set-cookie on this response is the session.
  Future<void> verifyOtp(String code) async {
    final mobile = _pendingMobile;
    if (mobile == null) {
      throw Exception('Enter your mobile number first.');
    }
    setBusy(true);
    try {
      final payload = await AuthService.verifyOtp(mobile, code.trim());
      // The session cookie now exists; fold any guest basket into the account
      // and stop sending the guest header from here on.
      await CartService.mergeGuest();
      final user = payload['user'];
      _account = CustomerAccount(
        user is Map
            ? {'user': Map<String, dynamic>.from(user)}
            : <String, dynamic>{},
      );
      _devOtp = null;
      _pendingMobile = null;
    } finally {
      setBusy(false);
    }
  }

  Future<void> logout() async {
    try {
      await AuthService.logout();
    } catch (_) {
      // Clearing the client is what matters; a dead server must not trap
      // somebody in a session they asked to end.
    }
    _account = null;
    ApiClient.instance.guestKey = null;
    notifyListeners();
  }

  /// Exposed so the API layer can force a sign-out on a confirmed 401.
  void handleSessionLost() {
    if (_account == null) return;
    _account = null;
    notifyListeners();
  }
}
