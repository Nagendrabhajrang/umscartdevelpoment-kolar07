import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/api_client.dart';
import '../models/models.dart';
import '../state/cart_state.dart';
import 'common.dart';

/// Product tile: image, name, unit, price and a quantity stepper.
///
/// The stepper is optimistic - it changes the number instantly and reconciles
/// with the server response, so tapping "+" never feels laggy.
class ProductCard extends StatelessWidget {
  const ProductCard({
    super.key,
    required this.product,
    required this.cart,
    this.onOpen,
    this.onAdded,
    this.compact = false,
  });

  final Product product;
  final CartState cart;
  final VoidCallback? onOpen;
  final VoidCallback? onAdded;
  final bool compact;

  Future<void> _change(BuildContext context, int next) async {
    try {
      final line = cart.cart.lines
          .where((l) => l.productId == product.id)
          .cast<CartLine?>()
          .firstWhere((l) => true, orElse: () => null);
      if (line == null && next > 0) {
        await cart.add(product, quantity: next);
        onAdded?.call();
      } else if (line != null) {
        await cart.setQuantity(line.id, next);
      }
    } on ApiException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final qty = cart.quantityOf(product.id);
    final hasDiscount = product.mrp > product.price;

    return TiltCard(
      onTap: onOpen,
      padding: EdgeInsets.zero,
      maxTilt: 0.035,
      radius: 22,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: RemoteImage(
                    url: product.imageUrl,
                    radius: 22,
                    fit: BoxFit.cover,
                  ),
                ),
                if (hasDiscount)
                  Positioned(
                    left: 8,
                    top: 8,
                    child: Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: AppTheme.sunsetGradient,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '${product.discount.round()}% off',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                Positioned(
                  right: 6,
                  top: 6,
                  child: Container(
                    height: 18,
                    width: 18,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: product.isVeg
                            ? const Color(0xFF16A34A)
                            : const Color(0xFFDC2626),
                        width: 1.6,
                      ),
                    ),
                    child: Center(
                      child: Container(
                        height: 8,
                        width: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: product.isVeg
                              ? const Color(0xFF16A34A)
                              : const Color(0xFFDC2626),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.2,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  product.unitLabel.isEmpty ? '1 pc' : product.unitLabel,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            money(product.price),
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w900,
                              color: AppTheme.ink,
                            ),
                          ),
                          if (hasDiscount)
                            Text(
                              money(product.mrp),
                              style: const TextStyle(
                                fontSize: 10.5,
                                color: AppTheme.muted,
                                decoration: TextDecoration.lineThrough,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (!product.inStock)
                      const Text(
                        'Sold out',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.rose,
                        ),
                      )
                    else if (qty == 0)
                      _AddButton(onTap: () => _change(context, 1))
                    else
                      _Stepper(
                        qty: qty,
                        onMinus: () => _change(context, qty - 1),
                        onPlus: () => _change(context, qty + 1),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 32,
        width: 58,
        decoration: BoxDecoration(
          gradient: AppTheme.brandGradient,
          borderRadius: BorderRadius.circular(11),
          boxShadow: [
            BoxShadow(
              color: AppTheme.brand.withOpacity(0.35),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Center(
          child: Text(
            'ADD',
            style: TextStyle(
              color: Colors.white,
              fontSize: 11.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.3,
            ),
          ),
        ),
      ),
    );
  }
}

class _Stepper extends StatelessWidget {
  const _Stepper({
    required this.qty,
    required this.onMinus,
    required this.onPlus,
  });

  final int qty;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      decoration: BoxDecoration(
        gradient: AppTheme.brandGradient,
        borderRadius: BorderRadius.circular(11),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _bubble(Icons.remove_rounded, onMinus),
          SizedBox(
            width: 20,
            child: Center(
              child: Text(
                '$qty',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          _bubble(Icons.add_rounded, onPlus),
        ],
      ),
    );
  }

  Widget _bubble(IconData icon, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: SizedBox(
          width: 26,
          height: 32,
          child: Icon(icon, size: 15, color: Colors.white),
        ),
      );
}
