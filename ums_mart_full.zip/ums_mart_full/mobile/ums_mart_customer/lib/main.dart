import 'package:flutter/material.dart';

import 'core/api_client.dart';
import 'core/app_theme.dart';
import 'core/config.dart';
import 'screens/splash_screen.dart';
import 'state/auth_state.dart';
import 'state/cart_state.dart';

void main() {
  runApp(const UmsMartApp());
}

/// Root of the storefront.
///
/// Mirrors the React app's provider stack: auth owns the session and sits above
/// cart, which needs the session to know whether it is a guest basket or an
/// account basket.
class UmsMartApp extends StatefulWidget {
  const UmsMartApp({super.key});

  @override
  State<UmsMartApp> createState() => _UmsMartAppState();
}

class _UmsMartAppState extends State<UmsMartApp> {
  final AuthState _auth = AuthState();
  late final CartState _cart;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _cart = CartState(_auth);
    _boot();
  }

  Future<void> _boot() async {
    await ApiClient.instance.init();
    // A confirmed 401 is the only thing allowed to clear the local profile.
    ApiClient.instance.onSessionLost = _auth.handleSessionLost;
    await _auth.restore();
    // Loads (or mints) the guest-cart key, then fetches the basket.
    await _cart.init();
    if (mounted) setState(() => _ready = true);
  }

  @override
  void dispose() {
    _cart.dispose();
    _auth.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (ApiConfig.isMisconfigured) return const _BuildConfigError();
    return MaterialApp(
      title: 'UMS Mart',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: SplashScreen(
        ready: _ready,
        auth: _auth,
        cart: _cart,
      ),
    );
  }
}

/// Shown when a release build was made without an API address.
///
/// Silently pointing a shipped app at 10.0.2.2 produces a dead app with cryptic
/// socket errors; naming the exact command to fix it does not.
class _BuildConfigError extends StatelessWidget {
  const _BuildConfigError();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: AppTheme.ink,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.settings_ethernet_rounded,
                    color: Colors.white, size: 46),
                const SizedBox(height: 20),
                const Text(
                  'Almost there',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'This build has no API address, so it cannot reach the shop.',
                  style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.5),
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white12,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Text(
                    ApiConfig.buildHint,
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'monospace',
                      fontSize: 12.5,
                      height: 1.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
