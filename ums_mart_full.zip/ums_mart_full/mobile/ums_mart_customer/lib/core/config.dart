import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb, kReleaseMode;

/// Where the Django API lives.
///
/// One place to change, because the correct host differs per target:
///
///   * Android emulator  -> 10.0.2.2 is the host machine's loopback
///   * iOS simulator     -> 127.0.0.1 works
///   * Physical device   -> your machine's LAN IP (run `ipconfig`, e.g. 192.168.1.38)
///   * Flutter web       -> localhost (and the API needs CORS/CSRF to trust it)
///
/// Everything below is overridable at build time:
///   flutter run --dart-define=API_BASE=http://192.168.1.38:8000
class ApiConfig {
  static const String override = String.fromEnvironment('API_BASE');

  /// A release build is the one that ships. `kReleaseMode` is true for
  /// `flutter build apk --release`, false for `flutter run`.
  static bool get isRelease => kReleaseMode;

  /// `--dart-define=API_BASE=relative` makes every request same-origin
  /// (`/api/v1/...`). That is the right choice when the app is served by a web
  /// server that proxies /api to Django, and it is the only option that works
  /// through a preview host.
  static bool get isRelative => override == 'relative';

  /// A physical handset cannot reach 10.0.2.2 — that address only exists inside
  /// the Android emulator. Rather than fail at runtime, a release build without
  /// an explicit API_BASE shows a clear message pointing at the fix.
  static const String buildHint =
      'No API address in this build. Rebuild with\n'
      'flutter build apk --release --dart-define=API_BASE=http://<your-pc-ip>:8000';

  static bool get isMisconfigured =>
      !isRelative && override.isEmpty && kReleaseMode;

  static String get baseUrl {
    if (isRelative) return '';
    if (override.isNotEmpty) return override;
    if (kIsWeb) return 'http://127.0.0.1:8000';
    if (Platform.isAndroid) return 'http://10.0.2.2:8000';
    return 'http://127.0.0.1:8000';
  }

  /// Same-origin root derived from the page, used in relative mode.
  static String get _origin => Uri.base.origin;

  /// Business endpoints live under /api/v1, auth under /api/auth.
  ///
  /// In relative mode these must be absolute URIs: Dio resolves a path against
  /// its own baseUrl, so a bare "/api/auth" would become "/api/v1/api/auth".
  static String get v1 => isRelative ? '$_origin/api/v1' : '$baseUrl/api/v1';
  /// Shared auth routes: CSRF, session, logout.  (/api/auth/...)
  static String get auth => isRelative ? '$_origin/api/auth' : '$baseUrl/api/auth';

  /// Customer auth routes: send-otp, verify-otp, profile.  (/api/customer/...)
  static String get customer =>
      isRelative ? '$_origin/api/customer' : '$baseUrl/api/customer';
  static String get admin => isRelative ? '$_origin/api/admin' : '$baseUrl/api/admin';
}
