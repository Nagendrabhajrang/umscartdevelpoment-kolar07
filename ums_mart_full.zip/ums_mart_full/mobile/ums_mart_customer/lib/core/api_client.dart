import 'dart:convert';

import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:path_provider/path_provider.dart';

import 'config.dart';

/// One Dio instance for the whole app.
///
/// Two things matter for this backend:
///
/// 1. **The session cookie.** Django authenticates with an HttpOnly
///    `ums_mart_sessionid` cookie. Dart's HTTP stack does not persist cookies by
///    default, so without [CookieManager] every request would be anonymous and
///    login would silently "not stick". The cookie jar is persisted to disk so
///    the session survives an app restart - the same seven days the web app gets.
///
/// 2. **CSRF.** Any POST/PUT/PATCH/DELETE made with a session cookie must echo
///    the `ums_mart_csrftoken` cookie in an `X-CSRFToken` header. A cookie jar
///    hides the cookie from us, so we read it out of the jar and set the header
///    ourselves on unsafe methods.
class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  static const String csrfCookieName = 'ums_mart_csrftoken';
  static const String csrfHeaderName = 'X-CSRFToken';

  late final Dio dio;
  CookieJar? _jar;
  bool _ready = false;

  /// Raised whenever the server confirms there is no session (401).
  /// The UI listens to this to send the shopper to the login screen.
  void Function()? onSessionLost;

  Future<void> init() async {
    if (_ready) return;

    dio = Dio(
      BaseOptions(
        baseUrl: ApiConfig.v1,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 25),
        headers: {'Accept': 'application/json'},
        // Let us decide what counts as an error; we normalise it ourselves.
        validateStatus: (status) => status != null && status < 500,
      ),
    );

    try {
      final dir = await getApplicationDocumentsDirectory();
      final jar = PersistCookieJar(
        ignoreExpires: false,
        storage: FileStorage('${dir.path}/ums_mart_cookies'),
      );
      _jar = jar;
      dio.interceptors.add(CookieManager(jar));
    } catch (_) {
      // Web / unsupported platform: fall back to an in-memory jar so web still
      // works. The session simply does not survive a page reload.
      final jar = CookieJar();
      _jar = jar;
      dio.interceptors.add(CookieManager(jar));
    }

    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final method = options.method.toUpperCase();
          if (const {'POST', 'PUT', 'PATCH', 'DELETE'}.contains(method)) {
            final token = await _csrfToken(options.uri);
            if (token != null) {
              options.headers[csrfHeaderName] = token;
            }
          }
          handler.next(options);
        },
      ),
    );

    _ready = true;
  }

  /// Read the CSRF cookie for [uri] from the jar, minting one if absent.
  Future<String?> _csrfToken(Uri uri) async {
    final jar = _jar;
    if (jar == null) return null;

    final cookies = await jar.loadForRequest(uri);
    for (final c in cookies) {
      if (c.name == csrfCookieName) return c.value;
    }

    // Nothing cached: ask the server to plant both CSRF and (crucially) a
    // session cookie if the shopper is already signed in.
    try {
      await dio.get<void>(
        '${ApiConfig.auth}/csrf/',
        options: Options(validateStatus: (_) => true),
      );
    } catch (_) {
      return null;
    }

    final fresh = await jar.loadForRequest(uri);
    for (final c in fresh) {
      if (c.name == csrfCookieName) return c.value;
    }
    return null;
  }

  // ---------------------------------------------------------------- helpers

  /// GET JSON from an absolute URL (auth endpoints live outside /api/v1).
  Future<dynamic> getAbsolute(String url, {Map<String, dynamic>? query}) =>
      _run(() => dio.get(url, queryParameters: query));

  Future<dynamic> postAbsolute(String url, {Object? body}) =>
      _run(() => dio.post(url, data: body));

  Future<dynamic> get(String path, {Map<String, dynamic>? query}) =>
      _run(() => dio.get(path, queryParameters: _clean(query)));

  Future<dynamic> post(String path, {Object? body}) =>
      _run(() => dio.post(path, data: body));

  Future<dynamic> patch(String path, {Object? body}) =>
      _run(() => dio.patch(path, data: body));

  Future<dynamic> delete(String path, {Object? body}) =>
      _run(() => dio.delete(path, data: body));

  Future<dynamic> _run(Future<Response<dynamic>> Function() call) async {
    Response<dynamic> response;
    try {
      response = await call();
    } on DioException catch (e) {
      throw ApiException(
        message: e.type == DioExceptionType.connectionError ||
                e.type == DioExceptionType.connectionTimeout
            ? 'Cannot reach the server. Is the API running on 8000?'
            : 'Network problem. Please try again.',
        status: 0,
        code: 'network_error',
      );
    }

    final status = response.statusCode ?? 0;
    if (status == 401) {
      onSessionLost?.call();
    }
    if (status >= 400) {
      throw ApiException.fromBody(response.data, status);
    }
    return response.data;
  }

  /// Drop null/empty query values: django-filter treats `?status=` as a real
  /// filter that matches nothing.
  Map<String, dynamic>? _clean(Map<String, dynamic>? query) {
    if (query == null) return null;
    final out = <String, dynamic>{};
    query.forEach((k, v) {
      if (v == null) return;
      if (v is String && v.trim().isEmpty) return;
      out[k] = v;
    });
    return out.isEmpty ? null : out;
  }

  /// Drop every cookie (session + CSRF). Used by sign-out and by a confirmed
  /// 401, so a stale session cookie can never be replayed.
  Future<void> clearSession() async {
    try {
      await _jar?.deleteAll();
    } catch (_) {
      // Ignore: the server-side row is what actually ends the session.
    }
  }

  // ------------------------------------------------------------ guest cart

  String? guestKey;

  Map<String, String> get guestHeaders =>
      guestKey == null ? const {} : {'X-Guest-Cart': guestKey!};
}

/// Every failure in the app arrives as this - one shape to render.
class ApiException implements Exception {
  ApiException({
    required this.message,
    required this.status,
    required this.code,
    this.details,
  });

  final String message;
  final int status;
  final String code;
  final Map<String, dynamic>? details;

  factory ApiException.fromBody(dynamic body, int status) {
    if (body is Map) {
      final err = body['error'];
      if (err is Map) {
        return ApiException(
          message: '${err['message'] ?? 'Something went wrong.'}',
          status: status,
          code: '${err['code'] ?? 'error'}',
          details: err['details'] is Map
              ? Map<String, dynamic>.from(err['details'] as Map)
              : null,
        );
      }
      if (body['detail'] != null) {
        return ApiException(
          message: '${body['detail']}',
          status: status,
          code: 'error',
        );
      }
    }
    if (body is String && body.isNotEmpty) {
      // An HTML error page means the request never reached the API (Django 404
      // page, proxy error). Never paste markup into the UI.
      var text = body;
      if (text.trimLeft().startsWith('<')) {
        final title = RegExp(r'<title>(.*?)</title>', dotAll: true)
            .firstMatch(text)
            ?.group(1);
        text = title == null || title.trim().isEmpty
            ? 'Unexpected HTML response (HTTP $status). Is the API URL right?'
            : 'Server said: ${title.trim()} (HTTP $status).';
      }
      return ApiException(
        message: text.length > 300 ? text.substring(0, 300) : text,
        status: status,
        code: 'error',
      );
    }
    return ApiException(
      message: 'Request failed (HTTP $status).',
      status: status,
      code: 'error',
    );
  }

  @override
  String toString() => message;

  /// Convenience for decoding list payloads that may or may not be paginated.
  static List<Map<String, dynamic>> asList(dynamic data) {
    if (data is List) {
      return data.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    }
    if (data is Map && data['results'] is List) {
      return (data['results'] as List)
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    return const [];
  }

  static Map<String, dynamic> asMap(dynamic data) {
    if (data is Map) return Map<String, dynamic>.from(data);
    return const {};
  }

  static String pretty(dynamic value) =>
      const JsonEncoder.withIndent('  ').convert(value);
}
