// Typed wrappers over the endpoints the React storefront already uses.
// Same URLs, same payloads - the Django API is untouched by this app.

import '../core/api_client.dart';
import '../core/config.dart';
import '../models/models.dart';

/// Turn a path the API returned (`/media/...`) into a URL the app can fetch.
///
/// In relative mode the request must stay same-origin so the web server can
/// proxy it, so the path is returned untouched.
String mediaUrl(String path) {
  if (path.isEmpty) return path;
  if (path.startsWith('http')) return path;
  if (ApiConfig.isRelative) return Uri.base.resolve(path).toString();
  return '${ApiConfig.baseUrl}$path';
}

class CatalogService {
  static Future<List<Category>> categories() async {
    final data = await ApiClient.instance
        .get('/catalog/categories/', query: {'page_size': 100});
    return ApiException.asList(data).map(Category.new).toList();
  }

  static Future<List<Product>> products({
    int page = 1,
    int pageSize = 20,
    String? search,
    int? category,
    bool? featured,
    String? ordering,
  }) async {
    final data = await ApiClient.instance.get(
      '/catalog/products/',
      query: {
        'page': page,
        'page_size': pageSize,
        'search': search,
        'category': category,
        'is_featured': featured == true ? true : null,
        'ordering': ordering,
      },
    );
    return ApiException.asList(data).map(Product.new).toList();
  }

  static Future<List<Product>> featured({int limit = 10}) async {
    final data = await ApiClient.instance
        .get('/catalog/products/featured/', query: {'page_size': limit});
    return ApiException.asList(data).map(Product.new).toList();
  }

  static Future<Product?> product(int id) async {
    final data = await ApiClient.instance.get('/catalog/products/$id/');
    final map = ApiException.asMap(data);
    return map.isEmpty ? null : Product(map);
  }

  static Future<List<Product>> related(int id) async {
    final data = await ApiClient.instance.get('/catalog/products/$id/related/');
    return ApiException.asList(data).map(Product.new).toList();
  }
}

class BannerService {
  static Future<List<BannerItem>> live() async {
    final data = await ApiClient.instance.get('/banners/live/');
    return ApiException.asList(data).map(BannerItem.new).toList();
  }

  static Future<void> registerClick(int id) async {
    try {
      await ApiClient.instance.get('/banners/$id/click/');
    } catch (_) {
      // A failed impression must never disturb the shopper.
    }
  }
}

class StoreService {
  static Future<StoreSettings> settings() async {
    final data = await ApiClient.instance.get('/store-settings/');
    return StoreSettings(ApiException.asMap(data));
  }
}

class CartService {
  static Future<Cart> get() async {
    final data = await ApiClient.instance
        .get('/cart/', query: ApiClient.instance.guestHeaders.isEmpty
            ? null
            : {'guest_cart': ApiClient.instance.guestKey});
    return Cart(ApiException.asMap(data));
  }

  static Future<CartSummary> summary() async {
    final data = await ApiClient.instance.get('/cart/summary/');
    return CartSummary(ApiException.asMap(data));
  }

  static Future<void> add(Product product, {int quantity = 1}) async {
    await ApiClient.instance.post('/cart/items/', body: {
      'product': product.id,
      'quantity': quantity,
      if (ApiClient.instance.guestKey != null)
        'guest_cart': ApiClient.instance.guestKey,
    });
  }

  static Future<void> setQuantity(int itemId, int quantity) async {
    await ApiClient.instance
        .patch('/cart/items/$itemId/', body: {'quantity': quantity});
  }

  static Future<void> remove(int itemId) async {
    await ApiClient.instance.delete('/cart/items/$itemId/');
  }

  static Future<Cart> applyCoupon(String code) async {
    final data =
        await ApiClient.instance.post('/cart/coupon/', body: {'code': code});
    return Cart(ApiException.asMap(data));
  }

  static Future<void> removeCoupon() async {
    await ApiClient.instance.delete('/cart/coupon/');
  }

  /// Folds the guest basket into the account. Called right after login.
  static Future<void> mergeGuest() async {
    final key = ApiClient.instance.guestKey;
    if (key == null) return;
    try {
      await ApiClient.instance
          .post('/cart/merge/', body: {'guest_cart': key});
      ApiClient.instance.guestKey = null;
    } catch (_) {
      // Non-fatal: the shopper keeps the account cart either way.
    }
  }
}

class AuthService {
  /// Step 1: identify by mobile. Returns `dev_otp` in development.
  static Future<Map<String, dynamic>> sendOtp(String mobile) async {
    final data = await ApiClient.instance
        .postAbsolute('${ApiConfig.customer}/send-otp/',
            body: {'mobile_number': mobile});
    return ApiException.asMap(data);
  }

  static Future<Map<String, dynamic>> resendOtp(String mobile) async {
    final data = await ApiClient.instance
        .postAbsolute('${ApiConfig.customer}/resend-otp/',
            body: {'mobile_number': mobile});
    return ApiException.asMap(data);
  }

  /// Step 2: exchange the code for a session. The server also adopts the guest
  /// basket inside this request, so the cart survives the login.
  static Future<Map<String, dynamic>> verifyOtp(
    String mobile,
    String code,
  ) async {
    final data = await ApiClient.instance
        .postAbsolute('${ApiConfig.customer}/verify-otp/', body: {
      'mobile_number': mobile,
      'code': code,
      if (ApiClient.instance.guestKey != null)
        'guest_cart': ApiClient.instance.guestKey,
    });
    return ApiException.asMap(data);
  }

  /// Who am I? 401 means the server confirmed there is no session.
  static Future<CustomerAccount?> session() async {
    final data = await ApiClient.instance
        .getAbsolute('${ApiConfig.auth}/session/');
    final map = ApiException.asMap(data);
    if (map.isEmpty || map['authenticated'] != true) return null;
    return CustomerAccount(map);
  }

  static Future<CustomerAccount> profile() async {
    final data = await ApiClient.instance
        .getAbsolute('${ApiConfig.customer}/profile/');
    return CustomerAccount(ApiException.asMap(data));
  }

  static Future<void> logout() async {
    await ApiClient.instance
        .postAbsolute('${ApiConfig.customer}/logout/', body: const {});
  }
}

class OrderService {
  static Future<List<OrderSummary>> mine() async {
    final data = await ApiClient.instance
        .get('/orders/mine/', query: {'ordering': '-created_at'});
    return ApiException.asList(data).map(OrderSummary.new).toList();
  }

  static Future<OrderSummary> get(int id) async {
    final data = await ApiClient.instance.get('/orders/$id/');
    return OrderSummary(ApiException.asMap(data));
  }

  static Future<OrderSummary> cancel(int id, String reason,
      {String note = ''}) async {
    final data = await ApiClient.instance
        .post('/orders/$id/cancel/', body: {'reason': reason, 'note': note});
    return OrderSummary(ApiException.asMap(data));
  }

  static Future<Map<String, dynamic>> lookup(
      String orderNumber, String mobile) async {
    final data = await ApiClient.instance.get('/orders/lookup/', query: {
      'order_number': orderNumber,
      'mobile_number': mobile,
    });
    return ApiException.asMap(data);
  }

  /// Validates the basket without committing: totals, delivery charge, issues.
  static Future<CartSummary> previewCheckout({
    int? addressId,
    String paymentMethod = 'cod',
    String? couponCode,
    String? notes,
  }) async {
    final data =
        await ApiClient.instance.post('/orders/checkout/preview/', body: {
      if (addressId != null) 'address': addressId,
      'payment_method': paymentMethod,
      if (couponCode != null) 'coupon_code': couponCode,
      if (notes != null && notes.isNotEmpty) 'customer_notes': notes,
    });
    return CartSummary(ApiException.asMap(data));
  }

  static Future<OrderSummary> checkout({
    required int addressId,
    String paymentMethod = 'cod',
    String? couponCode,
    String? notes,
  }) async {
    final data = await ApiClient.instance.post('/orders/checkout/', body: {
      'address': addressId,
      'payment_method': paymentMethod,
      if (couponCode != null) 'coupon_code': couponCode,
      if (notes != null && notes.isNotEmpty) 'customer_notes': notes,
    });
    return OrderSummary(ApiException.asMap(data));
  }
}

class AddressService {
  static Future<List<Address>> mine() async {
    final data = await ApiClient.instance.get('/addresses/mine/');
    return ApiException.asList(data).map(Address.new).toList();
  }

  static Future<Address> create(Map<String, dynamic> payload) async {
    final data =
        await ApiClient.instance.post('/addresses/mine/add/', body: payload);
    return Address(ApiException.asMap(data));
  }

  static Future<void> setDefault(int id) async {
    await ApiClient.instance.post('/addresses/$id/set-default/', body: const {});
  }

  static Future<void> remove(int id) async {
    await ApiClient.instance.delete('/addresses/$id/');
  }
}

class WishlistService {
  static Future<List<Product>> mine() async {
    final data = await ApiClient.instance.get('/wishlist/');
    final rows = ApiException.asList(data);
    // The endpoint returns wishlist items; unwrap the embedded product.
    return rows
        .map((row) => row['product'] is Map
            ? Product(Map<String, dynamic>.from(row['product'] as Map))
            : Product(row))
        .toList();
  }

  static Future<Map<String, dynamic>> toggle(int productId) async {
    final data = await ApiClient.instance
        .post('/wishlist/toggle/', body: {'product': productId});
    return ApiException.asMap(data);
  }
}
