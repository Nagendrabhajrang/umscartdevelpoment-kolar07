import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import '../widgets/product_card.dart';
import 'product_details_screen.dart';

/// A filtered, searchable product grid.
///
/// Used for "All products", a single category and "Trending" - the same screen
/// with different seeds, exactly like /products and /categories/:id on the web.
class ProductsScreen extends StatefulWidget {
  const ProductsScreen({
    super.key,
    required this.title,
    required this.auth,
    required this.cart,
    this.categoryId,
    this.featured = false,
  });

  final String title;
  final AuthState auth;
  final CartState cart;
  final int? categoryId;
  final bool featured;

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _scroll = ScrollController();
  final _searchController = TextEditingController();

  final List<Product> _items = [];
  int _page = 1;
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  String? _error;
  String _ordering = '-created_at';

  @override
  void initState() {
    super.initState();
    widget.cart.addListener(_repaint);
    _scroll.addListener(() {
      if (_scroll.position.pixels >=
              _scroll.position.maxScrollExtent - 400 &&
          !_loadingMore &&
          _hasMore) {
        _load(more: true);
      }
    });
    _load();
  }

  void _repaint() => setState(() {});

  @override
  void dispose() {
    widget.cart.removeListener(_repaint);
    _scroll.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load({bool more = false}) async {
    if (more) {
      setState(() => _loadingMore = true);
    } else {
      setState(() {
        _loading = true;
        _error = null;
        _page = 1;
        _hasMore = true;
        _items.clear();
      });
    }

    try {
      final rows = await CatalogService.products(
        page: _page,
        pageSize: 20,
        search: _searchController.text.trim().isEmpty
            ? null
            : _searchController.text.trim(),
        category: widget.categoryId,
        featured: widget.featured ? true : null,
        ordering: _ordering,
      );
      if (!mounted) return;
      setState(() {
        _items.addAll(rows);
        _hasMore = rows.length == 20;
        if (rows.isNotEmpty) _page += 1;
        _loading = false;
        _loadingMore = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
        _loadingMore = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: PopupMenuButton<String>(
              icon: const Icon(Icons.tune_rounded),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              onSelected: (value) {
                setState(() => _ordering = value);
                _load();
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: '-created_at', child: Text('Newest first')),
                PopupMenuItem(
                    value: 'selling_price', child: Text('Price: low to high')),
                PopupMenuItem(
                    value: '-selling_price', child: Text('Price: high to low')),
                PopupMenuItem(value: 'name', child: Text('Name A–Z')),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
            child: TextField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _load(),
              decoration: InputDecoration(
                hintText: 'Search in ${widget.title}',
                prefixIcon:
                    const Icon(Icons.search_rounded, color: AppTheme.brand),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          _load();
                        },
                      ),
              ),
            ),
          ),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.66,
        ),
        itemCount: 6,
        itemBuilder: (_, __) => const ShimmerBox(height: 220),
      );
    }

    if (_error != null && _items.isEmpty) {
      return EmptyView(
        icon: Icons.cloud_off_rounded,
        title: 'Could not load products',
        message: _error,
        actionLabel: 'Retry',
        onAction: _load,
      );
    }

    if (_items.isEmpty) {
      return const EmptyView(
        icon: Icons.search_off_rounded,
        title: 'Nothing here yet',
        message: 'Try a different search or category.',
      );
    }

    return RefreshIndicator(
      color: AppTheme.brand,
      onRefresh: () => _load(),
      child: GridView.builder(
        controller: _scroll,
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.66,
        ),
        itemCount: _items.length,
        itemBuilder: (context, i) {
          final p = _items[i];
          return ProductCard(
            product: p,
            cart: widget.cart,
            onOpen: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => ProductDetailsScreen(
                  productId: p.id,
                  auth: widget.auth,
                  cart: widget.cart,
                ),
              ));
            },
          );
        },
      ),
    );
  }
}
