import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import 'home_shell.dart';

/// Boot gate: shows the brand mark until the cookie session has been confirmed,
/// then hands over to the shell. Mirrors the web app's "never redirect before
/// the server answers" rule.
class SplashScreen extends StatelessWidget {
  const SplashScreen({
    super.key,
    required this.ready,
    required this.auth,
    required this.cart,
  });

  final bool ready;
  final AuthState auth;
  final CartState cart;

  @override
  Widget build(BuildContext context) {
    if (ready) {
      return HomeShell(auth: auth, cart: cart);
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppTheme.brandGradient),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _LogoMark(),
              SizedBox(height: 22),
              Text(
                'UMS Mart',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.8,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'Fresh groceries, delivered',
                style: TextStyle(
                  color: Color(0xFFCCF7DC),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                height: 22,
                width: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.4,
                  valueColor: AlwaysStoppedAnimation(Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LogoMark extends StatelessWidget {
  const _LogoMark();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 96,
      width: 96,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 30,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: const Center(
        child: Icon(Icons.shopping_basket_rounded,
            size: 48, color: AppTheme.brand),
      ),
    );
  }
}
