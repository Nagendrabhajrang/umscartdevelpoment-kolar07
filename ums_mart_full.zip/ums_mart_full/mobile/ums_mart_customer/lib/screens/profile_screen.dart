import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import '../widgets/product_card.dart';
import 'cart_screen.dart';
import 'login_screen.dart';
import 'orders_screen.dart';
import 'product_details_screen.dart';

/// Profile: identity, shortcuts, wishlist and sign-out.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.auth, required this.cart});

  final AuthState auth;
  final CartState cart;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<Product> _wishlist = const [];
  bool _loadingWishlist = false;

  @override
  void initState() {
    super.initState();
    widget.auth.addListener(_repaint);
    widget.cart.addListener(_repaint);
    _loadWishlist();
  }

  void _repaint() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    widget.auth.removeListener(_repaint);
    widget.cart.removeListener(_repaint);
    super.dispose();
  }

  Future<void> _loadWishlist() async {
    if (!widget.auth.isSignedIn) return;
    setState(() => _loadingWishlist = true);
    final rows = await WishlistService.mine().catchError((_) => <Product>[]);
    if (!mounted) return;
    setState(() {
      _wishlist = rows;
      _loadingWishlist = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final account = widget.auth.account;

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
        children: [
          const Text(
            'Profile',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.8,
              color: AppTheme.ink,
            ),
          ),
          const SizedBox(height: 16),
          if (account == null)
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppTheme.brandGradient,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.person_rounded,
                      color: Colors.white, size: 34),
                  const SizedBox(height: 10),
                  const Text(
                    'Sign in to your account',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Your orders, addresses and basket follow your mobile number.',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 12.5,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        await Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => LoginScreen(
                              auth: widget.auth,
                              cart: widget.cart,
                            ),
                          ),
                        );
                        _loadWishlist();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: AppTheme.brandDark,
                      ),
                      child: const Text('Sign in with mobile'),
                    ),
                  ),
                ],
              ),
            )
          else
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: AppTheme.brandGradient,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.brand.withOpacity(0.3),
                    blurRadius: 24,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    height: 56,
                    width: 56,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: Colors.white.withOpacity(0.35)),
                    ),
                    child: Center(
                      child: Text(
                        _initials(account.name),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          account.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.3,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          account.mobile,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 20),
          _Tile(
            icon: Icons.receipt_long_rounded,
            title: 'My orders',
            subtitle: 'Track and repeat past orders',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => OrdersScreen(auth: widget.auth),
            )),
          ),
          _Tile(
            icon: Icons.shopping_cart_rounded,
            title: 'Basket',
            subtitle: widget.cart.isEmpty
                ? 'Empty right now'
                : '${widget.cart.count} items waiting',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) =>
                  CartScreen(auth: widget.auth, cart: widget.cart),
            )),
          ),
          _Tile(
            icon: Icons.local_offer_rounded,
            title: 'Offers',
            subtitle: 'Coupons and seasonal savings',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('Apply coupon codes in the basket.')),
              );
            },
          ),
          const SizedBox(height: 20),
          if (widget.auth.isSignedIn) ...[
            const Text(
              'Saved for later',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: AppTheme.ink,
              ),
            ),
            const SizedBox(height: 10),
            if (_loadingWishlist)
              const ShimmerBox(height: 90)
            else if (_wishlist.isEmpty)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.line),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.favorite_border_rounded, color: AppTheme.muted),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Tap the heart on a product to keep it here.',
                        style: TextStyle(
                            fontSize: 12.5, color: AppTheme.muted),
                      ),
                    ),
                  ],
                ),
              )
            else
              SizedBox(
                height: 250,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _wishlist.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, i) {
                    final p = _wishlist[i];
                    return SizedBox(
                      width: 158,
                      child: ProductCard(
                        product: p,
                        cart: widget.cart,
                        onOpen: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => ProductDetailsScreen(
                              productId: p.id,
                              auth: widget.auth,
                              cart: widget.cart,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 26),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await widget.auth.logout();
                  await widget.cart.refresh();
                  if (!mounted) return;
                  setState(() => _wishlist = const []);
                },
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text('Sign out'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.rose,
                  minimumSize: const Size(0, 52),
                  side: BorderSide(color: AppTheme.rose.withOpacity(0.4)),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts.last.characters.first)
        .toUpperCase();
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.line),
            ),
            child: Row(
              children: [
                Container(
                  height: 38,
                  width: 38,
                  decoration: BoxDecoration(
                    color: AppTheme.mint,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, size: 18, color: AppTheme.brandDark),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.ink,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 11.5,
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded,
                    color: AppTheme.muted, size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
