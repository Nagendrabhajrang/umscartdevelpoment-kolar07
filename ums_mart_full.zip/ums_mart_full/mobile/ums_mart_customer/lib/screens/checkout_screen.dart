import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import 'address_form_sheet.dart';
import 'order_details_screen.dart';

/// Checkout: address, payment method, notes, then commit.
///
/// The totals come from `/orders/checkout/preview/` - the server is the only
/// thing allowed to price an order, so this screen never adds up money itself.
class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key, required this.auth, required this.cart});

  final AuthState auth;
  final CartState cart;

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  List<Address> _addresses = const [];
  Address? _selected;
  CartSummary? _preview;
  bool _loading = true;
  bool _placing = false;
  String? _error;
  final _notes = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _notes.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final addresses = await AddressService.mine();
      if (!mounted) return;
      setState(() {
        _addresses = addresses;
        _selected = addresses.isEmpty
            ? null
            : addresses.firstWhere((a) => a.isDefault, orElse: () => addresses.first);
      });
      await _refreshPreview();
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refreshPreview() async {
    try {
      final preview = await OrderService.previewCheckout(
        addressId: _selected?.id,
        couponCode: widget.cart.cart.couponCode,
        notes: _notes.text,
      );
      if (!mounted) return;
      setState(() => _preview = preview);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '$e');
    }
  }

  Future<void> _addAddress() async {
    final created = await showModalBottomSheet<Address>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const AddressFormSheet(),
    );
    if (created == null) return;
    setState(() {
      _addresses = [..._addresses, created];
      _selected = created;
    });
    await _refreshPreview();
  }

  Future<void> _placeOrder() async {
    final address = _selected;
    if (address == null) {
      setState(() => _error = 'Add a delivery address first.');
      return;
    }
    setState(() {
      _placing = true;
      _error = null;
    });
    try {
      final order = await OrderService.checkout(
        addressId: address.id,
        couponCode: widget.cart.cart.couponCode,
        notes: _notes.text,
      );
      await widget.cart.refresh();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => OrderDetailsScreen(orderId: order.id, auth: widget.auth),
        ),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _placing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(title: const Text('Checkout')),
      body: _loading
          ? const Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  ShimmerBox(height: 110),
                  SizedBox(height: 14),
                  ShimmerBox(height: 110),
                  SizedBox(height: 14),
                  ShimmerBox(height: 180),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 160),
              children: [
                const _StepLabel(number: '1', title: 'Delivery address'),
                const SizedBox(height: 10),
                if (_addresses.isEmpty)
                  _EmptyAddressCard(onAdd: _addAddress)
                else ...[
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.line),
                    ),
                    child: Column(
                      children: [
                        for (final a in _addresses)
                          RadioListTile<int>(
                            value: a.id,
                            // ignore: deprecated_member_use
                            groupValue: _selected?.id,
                            // ignore: deprecated_member_use
                            onChanged: (v) {
                              setState(() => _selected = a);
                              _refreshPreview();
                            },
                            activeColor: AppTheme.brand,
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 10),
                            title: Text(
                              '${a.label} · ${a.recipient}',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.ink,
                              ),
                            ),
                            subtitle: Text(
                              a.oneLine,
                              style: const TextStyle(
                                fontSize: 11.5,
                                color: AppTheme.muted,
                              ),
                            ),
                          ),
                        const Divider(height: 1),
                        TextButton.icon(
                          onPressed: _addAddress,
                          icon: const Icon(Icons.add_location_alt_rounded,
                              size: 18),
                          label: const Text('Add another address'),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 22),

                const _StepLabel(number: '2', title: 'Payment'),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: AppTheme.brand.withOpacity(0.45),
                        width: 1.4),
                  ),
                  child: Row(
                    children: [
                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          gradient: AppTheme.brandGradient,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.payments_rounded,
                            color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Cash on delivery',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.ink,
                              ),
                            ),
                            Text(
                              'Pay the rider when your order arrives',
                              style: TextStyle(
                                fontSize: 11.5,
                                color: AppTheme.muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.check_circle_rounded,
                          color: AppTheme.brand, size: 20),
                    ],
                  ),
                ),
                const SizedBox(height: 22),

                const _StepLabel(number: '3', title: 'Order notes'),
                const SizedBox(height: 10),
                TextField(
                  controller: _notes,
                  maxLines: 3,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                    hintText: 'Anything the rider should know? (optional)',
                  ),
                ),
                const SizedBox(height: 22),

                if (_preview != null) ...[
                  const _StepLabel(number: '4', title: 'Bill summary'),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.line),
                    ),
                    child: Column(
                      children: [
                        _row('Item total', money(_preview!.subtotal)),
                        if (_preview!.discount > 0)
                          _row('Coupon', '−${money(_preview!.discount)}',
                              good: true),
                        _row(
                          'Delivery',
                          _preview!.delivery == 0
                              ? 'FREE'
                              : money(_preview!.delivery),
                          good: _preview!.delivery == 0,
                        ),
                        if (_preview!.packaging > 0)
                          _row('Packaging', money(_preview!.packaging)),
                        if (_preview!.tax > 0)
                          _row('Taxes', money(_preview!.tax)),
                        const Divider(height: 22),
                        Row(
                          children: [
                            const Text(
                              'To pay',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.ink,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              money(_preview!.grandTotal),
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.ink,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],

                if (_error != null) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF1F3),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      _error!,
                      style: const TextStyle(
                        color: AppTheme.rose,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF0F172A).withOpacity(0.08),
              blurRadius: 24,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _preview == null
                        ? '—'
                        : money(_preview!.grandTotal),
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.ink,
                    ),
                  ),
                  const Text(
                    'Cash on delivery',
                    style: TextStyle(
                      fontSize: 10.5,
                      color: AppTheme.muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  onPressed: _placing ? null : _placeOrder,
                  child: _placing
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.2,
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          ),
                        )
                      : const Text('Place order'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String value, {bool good = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 12.5,
                color: AppTheme.muted,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            Text(
              value,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                color: good ? AppTheme.brandDark : AppTheme.ink,
              ),
            ),
          ],
        ),
      );
}

class _StepLabel extends StatelessWidget {
  const _StepLabel({required this.number, required this.title});

  final String number;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          height: 22,
          width: 22,
          decoration: const BoxDecoration(
            gradient: AppTheme.brandGradient,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              number,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14.5,
            fontWeight: FontWeight.w900,
            color: AppTheme.ink,
          ),
        ),
      ],
    );
  }
}

class _EmptyAddressCard extends StatelessWidget {
  const _EmptyAddressCard({required this.onAdd});
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        children: [
          const Icon(Icons.location_off_rounded,
              size: 34, color: AppTheme.muted),
          const SizedBox(height: 10),
          const Text(
            'No saved address yet',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: AppTheme.ink,
              fontSize: 13.5,
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.add_location_alt_rounded, size: 18),
            label: const Text('Add delivery address'),
          ),
        ],
      ),
    );
  }
}
