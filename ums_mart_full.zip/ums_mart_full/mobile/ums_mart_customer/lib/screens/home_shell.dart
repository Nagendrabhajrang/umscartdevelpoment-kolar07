import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import '../widgets/hero_carousel.dart';
import '../widgets/product_card.dart';
import 'cart_screen.dart';
import 'categories_screen.dart';
import 'orders_screen.dart';
import 'product_details_screen.dart';
import 'products_screen.dart';
import 'profile_screen.dart';
import 'search_screen.dart';

/// The shell: bottom navigation + the four top-level screens.
class HomeShell extends StatefulWidget {
  const HomeShell({
    super.key,
    required this.auth,
    required this.cart,
  });

  final AuthState auth;
  final CartState cart;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    widget.auth.addListener(_repaint);
    widget.cart.addListener(_repaint);
  }

  void _repaint() => setState(() {});

  @override
  void dispose() {
    widget.auth.removeListener(_repaint);
    widget.cart.removeListener(_repaint);
    super.dispose();
  }

  void _openTab(int i) => setState(() => _tab = i);

  @override
  Widget build(BuildContext context) {
    final pages = [
      _HomeTab(auth: widget.auth, cart: widget.cart, onTab: _openTab),
      CategoriesScreen(auth: widget.auth, cart: widget.cart),
      OrdersScreen(auth: widget.auth),
      ProfileScreen(auth: widget.auth, cart: widget.cart),
    ];

    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: _BottomBar(
        index: _tab,
        cartCount: widget.cart.count,
        onTap: _openTab,
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.index,
    required this.cartCount,
    required this.onTap,
  });

  final int index;
  final int cartCount;
  final void Function(int) onTap;

  static const _items = [
    (Icons.home_rounded, Icons.home_outlined, 'Home'),
    (Icons.grid_view_rounded, Icons.grid_view_outlined, 'Categories'),
    (Icons.receipt_long_rounded, Icons.receipt_long_outlined, 'Orders'),
    (Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
      height: 68,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(0.10),
            blurRadius: 28,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Row(
        children: List.generate(_items.length, (i) {
          final (active, inactive, label) = _items[i];
          final selected = i == index;
          return Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onTap(i),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 5),
                    decoration: BoxDecoration(
                      color: selected
                          ? AppTheme.brand.withOpacity(0.12)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Icon(
                          selected ? active : inactive,
                          size: 22,
                          color: selected ? AppTheme.brand : AppTheme.muted,
                        ),
                        if (i == 1 && cartCount > 0)
                          Positioned(
                            right: -8,
                            top: -6,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 1),
                              constraints: const BoxConstraints(minWidth: 16),
                              decoration: BoxDecoration(
                                gradient: AppTheme.sunsetGradient,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '$cartCount',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: selected ? FontWeight.w900 : FontWeight.w600,
                      color: selected ? AppTheme.ink : AppTheme.muted,
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

/// ---------------------------------------------------------------- home tab

class _HomeTab extends StatefulWidget {
  const _HomeTab({
    required this.auth,
    required this.cart,
    required this.onTab,
  });

  final AuthState auth;
  final CartState cart;
  final void Function(int) onTab;

  @override
  State<_HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<_HomeTab> {
  List<BannerItem> _banners = const [];
  List<Category> _categories = const [];
  List<Product> _featured = const [];
  List<Product> _popular = const [];
  StoreSettings? _store;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        BannerService.live().catchError((_) => <BannerItem>[]),
        CatalogService.categories().catchError((_) => <Category>[]),
        CatalogService.featured(limit: 12).catchError((_) => <Product>[]),
        CatalogService.products(pageSize: 12, ordering: '-created_at')
            .catchError((_) => <Product>[]),
        StoreService.settings().catchError((_) => StoreSettings(const {})),
      ]);
      if (!mounted) return;
      setState(() {
        _banners = results[0] as List<BannerItem>;
        _categories = results[1] as List<Category>;
        _featured = results[2] as List<Product>;
        _popular = results[3] as List<Product>;
        _store = results[4] as StoreSettings;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  Future<void> _refresh() => _load();

  void _openProduct(Product p) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProductDetailsScreen(
          productId: p.id,
          auth: widget.auth,
          cart: widget.cart,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.account;

    return RefreshIndicator(
      onRefresh: _refresh,
      color: AppTheme.brand,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user != null
                                ? 'Hi, ${user.name.split(' ').first}'
                                : 'Good ${_greeting()}',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.muted,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _store?.name ?? 'UMS Mart',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.7,
                              color: AppTheme.ink,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _RoundIcon(
                      icon: Icons.favorite_rounded,
                      onTap: () => widget.onTab(3),
                    ),
                    const SizedBox(width: 8),
                    _RoundIcon(
                      icon: Icons.shopping_cart_rounded,
                      badge: widget.cart.count,
                      onTap: () async {
                        await Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => CartScreen(
                              auth: widget.auth,
                              cart: widget.cart,
                            ),
                          ),
                        );
                        if (mounted) setState(() {});
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Search
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 2),
              child: GestureDetector(
                onTap: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => SearchScreen(
                        auth: widget.auth,
                        cart: widget.cart,
                      ),
                    ),
                  );
                  if (mounted) setState(() {});
                },
                child: Container(
                  height: 52,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppTheme.line),
                    boxShadow: AppTheme.softShadow,
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.search_rounded,
                          color: AppTheme.brand, size: 21),
                      SizedBox(width: 10),
                      Text(
                        'Search milk, atta, mangoes…',
                        style: TextStyle(
                          color: AppTheme.muted,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Hero carousel
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: _loading
                  ? const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: ShimmerBox(height: 210, radius: 26),
                    )
                  : HeroCarousel(
                      banners: _banners
                          .where((b) => b.placement == 'hero')
                          .toList(),
                      onTap: (b) {
                        if (b.linkedProduct > 0) {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ProductDetailsScreen(
                              productId: b.linkedProduct,
                              auth: widget.auth,
                              cart: widget.cart,
                            ),
                          ));
                        } else if (b.linkedCategory > 0) {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ProductsScreen(
                              title: 'Category',
                              categoryId: b.linkedCategory,
                              auth: widget.auth,
                              cart: widget.cart,
                            ),
                          ));
                        }
                      },
                    ),
            ),
          ),

          // Quick promises strip
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              child: Row(
                children: [
                  _Promises(
                    icon: Icons.bolt_rounded,
                    label: '${_store?.etaMinutes ?? 30} min',
                    caption: 'Delivery',
                    gradient: AppTheme.sunsetGradient,
                  ),
                  const SizedBox(width: 10),
                  _Promises(
                    icon: Icons.verified_rounded,
                    label: 'COD',
                    caption: 'Pay on arrival',
                    gradient: AppTheme.brandGradient,
                  ),
                  const SizedBox(width: 10),
                  _Promises(
                    icon: Icons.eco_rounded,
                    label: 'Farm',
                    caption: 'Fresh daily',
                    gradient: AppTheme.oceanGradient,
                  ),
                ],
              ),
            ),
          ),

          // Categories
          SliverToBoxAdapter(
            child: SectionHeader(
              title: 'Shop by category',
              subtitle: 'Everything for the week',
              actionLabel: 'All',
              onAction: () => widget.onTab(1),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 108,
              child: _loading
                  ? ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: 5,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (_, __) =>
                          const ShimmerBox(height: 104, width: 84),
                    )
                  : ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: _categories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, i) {
                        final c = _categories[i];
                        return _CategoryTile(
                          category: c,
                          index: i,
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => ProductsScreen(
                                title: c.name,
                                categoryId: c.id,
                                auth: widget.auth,
                                cart: widget.cart,
                              ),
                            ));
                          },
                        );
                      },
                    ),
            ),
          ),

          // Featured
          SliverToBoxAdapter(
            child: SectionHeader(
              title: 'Trending now',
              subtitle: 'Hand-picked this morning',
              actionLabel: 'See all',
              onAction: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ProductsScreen(
                    title: 'Trending',
                    featured: true,
                    auth: widget.auth,
                    cart: widget.cart,
                  ),
                ));
              },
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 250,
              child: _loading
                  ? ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: 4,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (_, __) =>
                          const ShimmerBox(height: 240, width: 158),
                    )
                  : ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: _featured.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, i) {
                        final p = _featured[i];
                        return SizedBox(
                          width: 158,
                          child: ProductCard(
                            product: p,
                            cart: widget.cart,
                            onOpen: () => _openProduct(p),
                          ),
                        );
                      },
                    ),
            ),
          ),

          // Grid
          SliverToBoxAdapter(
            child: SectionHeader(
              title: 'Fresh arrivals',
              subtitle: 'Newly stocked',
              actionLabel: 'Browse',
              onAction: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ProductsScreen(
                    title: 'All products',
                    auth: widget.auth,
                    cart: widget.cart,
                  ),
                ));
              },
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            sliver: _loading
                ? SliverGrid(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.66,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (_, __) => const ShimmerBox(height: 220),
                      childCount: 4,
                    ),
                  )
                : SliverGrid(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.66,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final p = _popular[i];
                        return ProductCard(
                          product: p,
                          cart: widget.cart,
                          onOpen: () => _openProduct(p),
                        );
                      },
                      childCount: _popular.length,
                    ),
                  ),
          ),

          if (_error != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  _error!,
                  style: const TextStyle(color: AppTheme.rose),
                ),
              ),
            ),

          const SliverToBoxAdapter(child: SizedBox(height: 110)),
        ],
      ),
    );
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    return 'evening';
  }
}

class _RoundIcon extends StatelessWidget {
  const _RoundIcon({required this.icon, this.badge = 0, this.onTap});

  final IconData icon;
  final int badge;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        width: 44,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: AppTheme.line),
          boxShadow: AppTheme.softShadow,
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Center(child: Icon(icon, size: 20, color: AppTheme.ink)),
            if (badge > 0)
              Positioned(
                right: 4,
                top: 4,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  constraints: const BoxConstraints(minWidth: 16),
                  decoration: BoxDecoration(
                    gradient: AppTheme.sunsetGradient,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$badge',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _Promises extends StatelessWidget {
  const _Promises({
    required this.icon,
    required this.label,
    required this.caption,
    required this.gradient,
  });

  final IconData icon;
  final String label;
  final String caption;
  final Gradient gradient;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 30,
              width: 30,
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 16, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w900,
                color: AppTheme.ink,
              ),
            ),
            Text(
              caption,
              style: const TextStyle(
                fontSize: 10.5,
                color: AppTheme.muted,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({
    required this.category,
    required this.index,
    required this.onTap,
  });

  final Category category;
  final int index;
  final VoidCallback onTap;

  static const _gradients = [
    AppTheme.brandGradient,
    AppTheme.sunsetGradient,
    AppTheme.berryGradient,
    AppTheme.oceanGradient,
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 84,
        child: Column(
          children: [
            Container(
              height: 74,
              width: 74,
              decoration: BoxDecoration(
                gradient: category.imageUrl.isEmpty
                    ? _gradients[index % _gradients.length]
                    : null,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0F172A).withOpacity(0.08),
                    blurRadius: 14,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: category.imageUrl.isEmpty
                  ? Center(
                      child: Text(
                        category.name.characters.first.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    )
                  : RemoteImage(url: category.imageUrl, radius: 24),
            ),
            const SizedBox(height: 7),
            Text(
              category.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: AppTheme.ink,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
