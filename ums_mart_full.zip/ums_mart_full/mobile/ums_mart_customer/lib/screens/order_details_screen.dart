import 'dart:async';

import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../widgets/common.dart';

/// One order, live.
///
/// Deliberately fetches `GET /orders/{id}/` on open and every 20 seconds while
/// visible. The web build shows a snapshot handed over by the router; here the
/// shopper sees the admin's status change without doing anything.
class OrderDetailsScreen extends StatefulWidget {
  const OrderDetailsScreen({
    super.key,
    required this.orderId,
    required this.auth,
  });

  final int orderId;
  final AuthState auth;

  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen>
    with WidgetsBindingObserver {
  OrderSummary? _order;
  bool _loading = true;
  String? _error;
  Timer? _poll;
  bool _visible = true;
  bool _cancelling = false;

  static const _steps = [
    'pending',
    'confirmed',
    'processing',
    'out_for_delivery',
    'delivered',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _poll = Timer.periodic(const Duration(seconds: 20), (_) {
      if (_visible) _load(silent: true);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _visible = state == AppLifecycleState.resumed;
    if (_visible) _load(silent: true);
  }

  @override
  void dispose() {
    _poll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final order = await OrderService.get(widget.orderId);
      if (!mounted) return;
      setState(() {
        _order = order;
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  Future<void> _cancel() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('Cancel this order?'),
        content: const Text(
            'The items go back to stock and any coupon is released.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep it'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Cancel order',
                style: TextStyle(color: AppTheme.rose)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _cancelling = true);
    try {
      final updated = await OrderService.cancel(
          widget.orderId, 'customer_request');
      if (!mounted) return;
      setState(() => _order = updated);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Order cancelled')),
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final order = _order;

    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(
        title: Text(order?.number ?? 'Order'),
        actions: [
          IconButton(
            onPressed: () => _load(),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading
          ? const Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  ShimmerBox(height: 120),
                  SizedBox(height: 14),
                  ShimmerBox(height: 160),
                  SizedBox(height: 14),
                  ShimmerBox(height: 120),
                ],
              ),
            )
          : order == null
              ? EmptyView(
                  icon: Icons.error_outline_rounded,
                  title: 'Order not found',
                  message: _error,
                  actionLabel: 'Go back',
                  onAction: () => Navigator.of(context).maybePop(),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
                  children: [
                    _StatusHero(order: order, steps: _steps),
                    const SizedBox(height: 16),
                    if (order.items.isNotEmpty)
                      _Section(
                        title: 'Items (${order.items.length})',
                        child: Column(
                          children: [
                            for (final raw in order.items)
                              if (raw is Map) _ItemRow(item: raw),
                          ],
                        ),
                      ),
                    const SizedBox(height: 14),
                    _Section(
                      title: 'Bill',
                      child: Column(
                        children: [
                          _kv('Total paid on delivery', money(order.total),
                              bold: true),
                          _kv('Payment', order.paymentLabel),
                          _kv('Method',
                              order.paymentMethod.toUpperCase()),
                        ],
                      ),
                    ),
                    if (order.history.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      _Section(
                        title: 'Timeline',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final raw in order.history.reversed)
                              if (raw is Map)
                                _TimelineRow(entry: raw),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    if (order.status == 'pending' ||
                        order.status == 'confirmed')
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton(
                          onPressed: _cancelling ? null : _cancel,
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppTheme.rose,
                            minimumSize: const Size(0, 52),
                            side: BorderSide(
                                color: AppTheme.rose.withOpacity(0.4)),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16)),
                          ),
                          child: const Text(
                            'Cancel order',
                            style: TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }

  Widget _kv(String label, String value, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 12.5,
                color: AppTheme.muted,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            Text(
              value,
              style: TextStyle(
                fontSize: bold ? 14 : 12.5,
                fontWeight: bold ? FontWeight.w900 : FontWeight.w700,
                color: AppTheme.ink,
              ),
            ),
          ],
        ),
      );
}

class _StatusHero extends StatelessWidget {
  const _StatusHero({required this.order, required this.steps});

  final OrderSummary order;
  final List<String> steps;

  @override
  Widget build(BuildContext context) {
    final cancelled = order.status == 'cancelled';
    final current = steps.indexOf(order.status);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: cancelled ? AppTheme.sunsetGradient : AppTheme.brandGradient,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: (cancelled ? AppTheme.rose : AppTheme.brand)
                .withOpacity(0.28),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            cancelled ? 'Order cancelled' : order.statusLabel,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.6,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            cancelled
                ? 'Refund and stock handled automatically'
                : order.status == 'delivered'
                    ? 'Delivered — enjoy!'
                    : 'Arriving in about ${order.etaMinutes.isEmpty ? '30' : order.etaMinutes} minutes',
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (!cancelled) ...[
            const SizedBox(height: 18),
            Row(
              children: List.generate(steps.length, (i) {
                final done = i <= current;
                return Expanded(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              height: 3,
                              color: i == 0
                                  ? Colors.transparent
                                  : (i <= current
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.3)),
                            ),
                          ),
                          Container(
                            height: 18,
                            width: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: done
                                  ? Colors.white
                                  : Colors.white.withOpacity(0.28),
                            ),
                            child: done
                                ? const Icon(Icons.check_rounded,
                                    size: 11, color: AppTheme.brandDark)
                                : null,
                          ),
                          Expanded(
                            child: Container(
                              height: 3,
                              color: i == steps.length - 1
                                  ? Colors.transparent
                                  : (i < current
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.3)),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        order.status == steps[i] ? order.statusLabel : steps[i]
                            .replaceAll('_', ' ')
                            .split(' ')
                            .map((w) => w.isEmpty
                                ? w
                                : '${w[0].toUpperCase()}${w.substring(1)}')
                            .join(' '),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 8.5,
                          fontWeight:
                              done ? FontWeight.w800 : FontWeight.w600,
                          color: Colors.white
                              .withOpacity(done ? 1 : 0.65),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ),
          ],
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w900,
              color: AppTheme.ink,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class _ItemRow extends StatelessWidget {
  const _ItemRow({required this.item});
  final Map item;

  @override
  Widget build(BuildContext context) {
    final name = '${item['product_name'] ?? 'Item'}';
    final qty = item['quantity'] ?? 1;
    final unit = '${item['unit_label'] ?? ''}';
    final total = item['line_total'];

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            height: 38,
            width: 38,
            decoration: BoxDecoration(
              color: AppTheme.mint,
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(Icons.shopping_bag_rounded,
                size: 18, color: AppTheme.brandDark),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.ink,
                  ),
                ),
                Text(
                  '$unit × $qty',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            money(double.tryParse('${total ?? 0}') ?? 0),
            style: const TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: AppTheme.ink,
            ),
          ),
        ],
      ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  const _TimelineRow({required this.entry});
  final Map entry;

  @override
  Widget build(BuildContext context) {
    final status = '${entry['to_status'] ?? ''}';
    final at = '${entry['created_at'] ?? ''}';
    final note = '${entry['note'] ?? ''}';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 4),
            height: 8,
            width: 8,
            decoration: const BoxDecoration(
              color: AppTheme.brand,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  status.replaceAll('_', ' ').toUpperCase(),
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.ink,
                    letterSpacing: 0.4,
                  ),
                ),
                if (note.isNotEmpty)
                  Text(
                    note,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.muted),
                  ),
                Text(
                  at.length > 16 ? at.substring(0, 16).replaceAll('T', ' ') : at,
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: AppTheme.muted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
