import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import '../widgets/product_card.dart';
import 'product_details_screen.dart';

/// Search with debounced queries and a suggestion list from the catalogue.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.auth, required this.cart});

  final AuthState auth;
  final CartState cart;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  final _focus = FocusNode();
  Timer? _debounce;
  List<Product> _results = const [];
  bool _loading = false;
  bool _searched = false;
  String? _error;

  static const _suggestions = [
    'Milk',
    'Eggs',
    'Atta',
    'Rice',
    'Tomatoes',
    'Onions',
    'Bananas',
    'Coffee',
  ];

  @override
  void initState() {
    super.initState();
    widget.cart.addListener(_repaint);
    _controller.addListener(_onChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _focus.requestFocus());
  }

  void _repaint() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _debounce?.cancel();
    widget.cart.removeListener(_repaint);
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onChanged() {
    _debounce?.cancel();
    final query = _controller.text.trim();
    if (query.isEmpty) {
      setState(() {
        _results = const [];
        _searched = false;
        _loading = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 350), () => _search(query));
  }

  Future<void> _search(String query) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await CatalogService.products(search: query, pageSize: 30);
      if (!mounted) return;
      setState(() {
        _results = rows;
        _searched = true;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(right: 16),
          child: TextField(
            controller: _controller,
            focusNode: _focus,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => _search(v.trim()),
            decoration: InputDecoration(
              hintText: 'Search products',
              isDense: true,
              prefixIcon:
                  const Icon(Icons.search_rounded, color: AppTheme.brand),
              suffixIcon: _controller.text.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded, size: 18),
                      onPressed: _controller.clear,
                    ),
            ),
          ),
        ),
      ),
      body: _body(),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(color: AppTheme.brand));
    }
    if (_error != null) {
      return EmptyView(
        icon: Icons.cloud_off_rounded,
        title: 'Search failed',
        message: _error,
      );
    }
    if (!_searched) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
        children: [
          const Text(
            'Popular searches',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: AppTheme.ink,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final s in _suggestions)
                AppPill(
                  label: s,
                  icon: Icons.search_rounded,
                  onTap: () {
                    _controller.text = s;
                    _search(s);
                  },
                ),
            ],
          ),
        ],
      );
    }
    if (_results.isEmpty) {
      return const EmptyView(
        icon: Icons.search_off_rounded,
        title: 'No matches',
        message: 'Try a shorter word, or browse categories instead.',
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.66,
      ),
      itemCount: _results.length,
      itemBuilder: (context, i) {
        final p = _results[i];
        return ProductCard(
          product: p,
          cart: widget.cart,
          onOpen: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => ProductDetailsScreen(
              productId: p.id,
              auth: widget.auth,
              cart: widget.cart,
            ),
          )),
        );
      },
    );
  }
}
