import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/app_theme.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import 'checkout_screen.dart';
import 'login_screen.dart';

/// The basket: line items with steppers, a bill breakdown, coupons and the
/// checkout action. Same rules as the web build - the server prices everything,
/// this screen only displays what /cart/summary/ returns.
class CartScreen extends StatefulWidget {
  const CartScreen({super.key, required this.auth, required this.cart});

  final AuthState auth;
  final CartState cart;

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _coupon = TextEditingController();
  bool _applying = false;

  @override
  void initState() {
    super.initState();
    widget.cart.addListener(_repaint);
    widget.cart.refresh();
  }

  void _repaint() => setState(() {});

  @override
  void dispose() {
    widget.cart.removeListener(_repaint);
    _coupon.dispose();
    super.dispose();
  }

  Future<void> _applyCoupon() async {
    final code = _coupon.text.trim();
    if (code.isEmpty) return;
    setState(() => _applying = true);
    try {
      await widget.cart.applyCoupon(code);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Coupon applied')),
      );
      _coupon.clear();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _applying = false);
    }
  }

  Future<void> _goToCheckout() async {
    if (widget.cart.isEmpty) return;

    if (!widget.auth.isSignedIn) {
      final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(
          builder: (_) => LoginScreen(auth: widget.auth, cart: widget.cart),
        ),
      );
      if (ok != true) return;
    }

    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            CheckoutScreen(auth: widget.auth, cart: widget.cart),
      ),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cart = widget.cart.cart;
    final summary = widget.cart.summary;
    final lines = cart.lines;

    return Scaffold(
      backgroundColor: AppTheme.surface,
      appBar: AppBar(title: const Text('Your basket')),
      body: lines.isEmpty
          ? EmptyView(
              icon: Icons.shopping_basket_outlined,
              title: 'Your basket is empty',
              message: 'Add fresh produce and it will show up here.',
              actionLabel: 'Start shopping',
              onAction: () => Navigator.of(context).maybePop(),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 180),
              children: [
                // Delivery promise
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: AppTheme.brandGradient,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.bolt_rounded,
                          color: Colors.white, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Arriving in about 30 minutes',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.95),
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      Text(
                        '${cart.itemCount} item${cart.itemCount == 1 ? '' : 's'}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Lines
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppTheme.line),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < lines.length; i++) ...[
                        _LineRow(
                          line: lines[i],
                          onMinus: () => widget.cart.setQuantity(
                              lines[i].id, lines[i].quantity - 1),
                          onPlus: () => widget.cart.setQuantity(
                              lines[i].id, lines[i].quantity + 1),
                          onRemove: () => widget.cart.remove(lines[i].id),
                        ),
                        if (i != lines.length - 1)
                          const Divider(height: 1, indent: 16, endIndent: 16),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Coupon
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppTheme.line),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.local_offer_rounded,
                              size: 17, color: AppTheme.amber),
                          const SizedBox(width: 8),
                          const Text(
                            'Have a coupon?',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              color: AppTheme.ink,
                            ),
                          ),
                          const Spacer(),
                          if (cart.couponCode != null)
                            TextButton(
                              onPressed: () => widget.cart.removeCoupon(),
                              child: const Text('Remove'),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (cart.couponCode != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 10),
                          decoration: BoxDecoration(
                            color: AppTheme.mint,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.check_circle_rounded,
                                  size: 16, color: AppTheme.brandDark),
                              const SizedBox(width: 8),
                              Text(
                                '${cart.couponCode} applied',
                                style: const TextStyle(
                                  color: AppTheme.brandDark,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12.5,
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _coupon,
                                textCapitalization:
                                    TextCapitalization.characters,
                                decoration: const InputDecoration(
                                  hintText: 'Enter code',
                                  isDense: true,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            ElevatedButton(
                              onPressed: _applying ? null : _applyCoupon,
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size(84, 46),
                              ),
                              child: _applying
                                  ? const SizedBox(
                                      height: 16,
                                      width: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation(Colors.white),
                                      ),
                                    )
                                  : const Text('Apply'),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Bill
                if (summary != null)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppTheme.line),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Bill details',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            color: AppTheme.ink,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _BillRow(label: 'Item total', value: summary.subtotal),
                        if (summary.discount > 0)
                          _BillRow(
                            label: 'Coupon discount',
                            value: -summary.discount,
                            highlight: true,
                          ),
                        _BillRow(
                          label: 'Delivery',
                          value: summary.delivery,
                          free: summary.delivery == 0,
                        ),
                        if (summary.packaging > 0)
                          _BillRow(
                              label: 'Packaging', value: summary.packaging),
                        if (summary.tax > 0)
                          _BillRow(label: 'Taxes', value: summary.tax),
                        const Divider(height: 24),
                        Row(
                          children: [
                            const Text(
                              'To pay',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.ink,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              money(summary.grandTotal),
                              style: const TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.ink,
                              ),
                            ),
                          ],
                        ),
                        if (summary.savings > 0)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              decoration: BoxDecoration(
                                color: AppTheme.mint,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.savings_rounded,
                                      size: 14, color: AppTheme.brandDark),
                                  const SizedBox(width: 6),
                                  Text(
                                    'You save ${money(summary.savings)} on this order',
                                    style: const TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      color: AppTheme.brandDark,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
      bottomNavigationBar: lines.isEmpty
          ? null
          : Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0F172A).withOpacity(0.08),
                    blurRadius: 24,
                    offset: const Offset(0, -6),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          summary == null
                              ? money(cart.subtotal)
                              : money(summary.grandTotal),
                          style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w900,
                            color: AppTheme.ink,
                          ),
                        ),
                        const Text(
                          'incl. all charges',
                          style: TextStyle(
                            fontSize: 10.5,
                            color: AppTheme.muted,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _goToCheckout,
                        child: Text(
                          widget.auth.isSignedIn
                              ? 'Proceed to checkout'
                              : 'Sign in to checkout',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _LineRow extends StatelessWidget {
  const _LineRow({
    required this.line,
    required this.onMinus,
    required this.onPlus,
    required this.onRemove,
  });

  final CartLine line;
  final VoidCallback onMinus;
  final VoidCallback onPlus;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          SizedBox(
            height: 58,
            width: 58,
            child: RemoteImage(url: line.imageUrl, radius: 14),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  line.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  line.unitLabel.isEmpty ? '' : line.unitLabel,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      money(line.lineTotal),
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        color: AppTheme.ink,
                      ),
                    ),
                    if (!line.isAvailable) ...[
                      const SizedBox(width: 8),
                      const Text(
                        'unavailable',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.rose,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Column(
            children: [
              IconButton(
                onPressed: onRemove,
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.delete_outline_rounded, size: 18),
                color: AppTheme.muted,
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: AppTheme.brandGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    _step(Icons.remove_rounded, onMinus),
                    SizedBox(
                      width: 18,
                      child: Text(
                        '${line.quantity}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    _step(Icons.add_rounded, onPlus),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _step(IconData icon, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: SizedBox(
          height: 28,
          width: 24,
          child: Icon(icon, size: 14, color: Colors.white),
        ),
      );
}

class _BillRow extends StatelessWidget {
  const _BillRow({
    required this.label,
    required this.value,
    this.highlight = false,
    this.free = false,
  });

  final String label;
  final double value;
  final bool highlight;
  final bool free;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 12.5,
              color: AppTheme.muted,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          Text(
            free ? 'FREE' : '${value < 0 ? '−' : ''}${money(value.abs())}',
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: free || highlight ? AppTheme.brandDark : AppTheme.ink,
            ),
          ),
        ],
      ),
    );
  }
}
