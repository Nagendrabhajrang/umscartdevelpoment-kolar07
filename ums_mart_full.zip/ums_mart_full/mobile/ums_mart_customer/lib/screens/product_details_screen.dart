import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import '../widgets/product_card.dart';
import 'cart_screen.dart';

/// Product page: big artwork, price block, quantity stepper, related items.
///
/// Uses a collapsing header with a perspective-scaled image so the transition
/// from the grid feels continuous rather than a hard cut.
class ProductDetailsScreen extends StatefulWidget {
  const ProductDetailsScreen({
    super.key,
    required this.productId,
    required this.auth,
    required this.cart,
  });

  final int productId;
  final AuthState auth;
  final CartState cart;

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  Product? _product;
  List<Product> _related = const [];
  bool _loading = true;
  String? _error;
  int _qty = 1;
  final ScrollController _scroll = ScrollController();
  double _offset = 0;

  @override
  void initState() {
    super.initState();
    widget.cart.addListener(_repaint);
    _scroll.addListener(() {
      setState(() => _offset = _scroll.offset.clamp(0, 240));
    });
    _load();
  }

  void _repaint() => setState(() {});

  @override
  void dispose() {
    widget.cart.removeListener(_repaint);
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final product = await CatalogService.product(widget.productId);
      final related = await CatalogService.related(widget.productId)
          .catchError((_) => <Product>[]);
      if (!mounted) return;
      setState(() {
        _product = product;
        _related = related;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    }
  }

  Future<void> _addToCart() async {
    final product = _product;
    if (product == null) return;
    try {
      await widget.cart.add(product, quantity: _qty);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${product.name} × $_qty added'),
          action: SnackBarAction(
            label: 'View cart',
            textColor: AppTheme.brandLight,
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) =>
                    CartScreen(auth: widget.auth, cart: widget.cart),
              ));
            },
          ),
        ),
      );
      setState(() => _qty = 1);
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                ShimmerBox(height: 300, radius: 26),
                SizedBox(height: 16),
                ShimmerBox(height: 26, width: 220),
                SizedBox(height: 10),
                ShimmerBox(height: 16, width: 140),
                SizedBox(height: 20),
                ShimmerBox(height: 90),
              ],
            ),
          ),
        ),
      );
    }

    final product = _product;
    if (product == null) {
      return Scaffold(
        appBar: AppBar(),
        body: EmptyView(
          icon: Icons.error_outline_rounded,
          title: 'Product unavailable',
          message: _error ?? 'This item may have been removed.',
          actionLabel: 'Go back',
          onAction: () => Navigator.of(context).maybePop(),
        ),
      );
    }

    final inCart = widget.cart.quantityOf(product.id);
    final progress = (_offset / 240).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: AppTheme.surface,
      body: Stack(
        children: [
          CustomScrollView(
            controller: _scroll,
            slivers: [
              SliverAppBar(
                expandedHeight: 300,
                pinned: true,
                backgroundColor: Colors.white,
                surfaceTintColor: Colors.white,
                leading: Padding(
                  padding: const EdgeInsets.all(8),
                  child: _CircleButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: () => Navigator.of(context).maybePop(),
                  ),
                ),
                actions: [
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: _CircleButton(
                      icon: Icons.shopping_cart_rounded,
                      badge: widget.cart.count,
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => CartScreen(
                              auth: widget.auth, cart: widget.cart),
                        ));
                      },
                    ),
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(24, 60, 24, 16),
                    child: Transform.scale(
                      scale: 1 - (progress * 0.16),
                      child: RemoteImage(url: product.imageUrl, radius: 26),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          if (product.categoryName.isNotEmpty)
                            AppPill(
                              label: product.categoryName,
                              color: AppTheme.brand,
                            ),
                          const Spacer(),
                          if (product.inStock)
                            Text(
                              '${product.available} in stock',
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.brand,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        product.name,
                        style: const TextStyle(
                          fontSize: 24,
                          height: 1.15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.6,
                          color: AppTheme.ink,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        [
                          if (product.brand.isNotEmpty) product.brand,
                          if (product.unitLabel.isNotEmpty) product.unitLabel,
                        ].join(' · '),
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppTheme.muted,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            money(product.price),
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                              color: AppTheme.ink,
                            ),
                          ),
                          if (product.mrp > product.price) ...[
                            const SizedBox(width: 8),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Text(
                                money(product.mrp),
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: AppTheme.muted,
                                  decoration: TextDecoration.lineThrough,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              margin: const EdgeInsets.only(bottom: 4),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: AppTheme.mint,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'Save ${money(product.mrp - product.price)}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                  color: AppTheme.brandDark,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.line),
                        ),
                        child: Column(
                          children: [
                            _MetaRow(
                              icon: Icons.bolt_rounded,
                              title: 'Delivered in 30 minutes',
                              subtitle: 'From your nearest dark store',
                            ),
                            const Divider(height: 22),
                            _MetaRow(
                              icon: Icons.payments_rounded,
                              title: 'Cash on delivery',
                              subtitle: 'Pay the rider when it arrives',
                            ),
                            const Divider(height: 22),
                            _MetaRow(
                              icon: product.isVeg
                                  ? Icons.eco_rounded
                                  : Icons.local_dining_rounded,
                              title: product.isVeg
                                  ? 'Vegetarian'
                                  : 'Non-vegetarian',
                              subtitle: 'Checked and packed fresh',
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
              if (_related.isNotEmpty)
                SliverToBoxAdapter(
                  child: Column(
                    children: [
                      const SectionHeader(
                        title: 'Goes well with this',
                        subtitle: 'Often bought together',
                      ),
                      SizedBox(
                        height: 250,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          itemCount: _related.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (context, i) {
                            final p = _related[i];
                            return SizedBox(
                              width: 158,
                              child: ProductCard(
                                product: p,
                                cart: widget.cart,
                                onOpen: () {
                                  Navigator.of(context).pushReplacement(
                                    MaterialPageRoute(
                                      builder: (_) => ProductDetailsScreen(
                                        productId: p.id,
                                        auth: widget.auth,
                                        cart: widget.cart,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              const SliverToBoxAdapter(child: SizedBox(height: 120)),
            ],
          ),

          // Sticky purchase bar
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0F172A).withOpacity(0.10),
                    blurRadius: 26,
                    offset: const Offset(0, -8),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    _QtyStepper(
                      qty: _qty,
                      onMinus: () =>
                          setState(() => _qty = (_qty - 1).clamp(1, 20)),
                      onPlus: () => setState(
                          () => _qty = (_qty + 1).clamp(1, product.maxOrderQty)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: product.inStock
                          ? ElevatedButton(
                              onPressed: _addToCart,
                              child: Text(
                                inCart > 0
                                    ? 'Add another · ${money(product.price * _qty)}'
                                    : 'Add to cart · ${money(product.price * _qty)}',
                              ),
                            )
                          : ElevatedButton(
                              onPressed: null,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.line,
                                foregroundColor: AppTheme.muted,
                              ),
                              child: const Text('Out of stock'),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QtyStepper extends StatelessWidget {
  const _QtyStepper({
    required this.qty,
    required this.onMinus,
    required this.onPlus,
  });

  final int qty;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.line),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onMinus,
            icon: const Icon(Icons.remove_rounded, size: 18),
          ),
          Text(
            '$qty',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
          ),
          IconButton(
            onPressed: onPlus,
            icon: const Icon(Icons.add_rounded, size: 18),
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, this.onTap, this.badge = 0});

  final IconData icon;
  final VoidCallback? onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 42,
        width: 42,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: AppTheme.softShadow,
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Center(child: Icon(icon, size: 19, color: AppTheme.ink)),
            if (badge > 0)
              Positioned(
                right: 2,
                top: 2,
                child: Container(
                  height: 15,
                  width: 15,
                  decoration: const BoxDecoration(
                    gradient: AppTheme.sunsetGradient,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      '$badge',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MetaRow extends StatelessWidget {
  const _MetaRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          height: 34,
          width: 34,
          decoration: BoxDecoration(
            color: AppTheme.mint,
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(icon, size: 17, color: AppTheme.brandDark),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.ink,
                ),
              ),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 11.5,
                  color: AppTheme.muted,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
