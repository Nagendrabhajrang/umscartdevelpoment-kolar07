import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/api_client.dart';
import '../core/app_theme.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';

/// Mobile + OTP login, the same two-step flow the storefront uses.
///
/// In development the API echoes the code back as `dev_otp`; it is surfaced in
/// a banner so this screen is testable without an SMS provider. In production
/// the field is absent and the shopper reads the SMS.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.auth, this.cart});

  final AuthState auth;

  /// Optional: when the login is reached from the basket, the cart is refreshed
  /// so the adopted guest basket appears immediately.
  final CartState? cart;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _mobile = TextEditingController();
  final _code = TextEditingController();
  final _otpFocus = FocusNode();

  bool _otpStage = false;
  bool _busy = false;
  String? _devOtp;
  String? _error;
  int _cooldown = 0;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    _mobile.dispose();
    _code.dispose();
    _otpFocus.dispose();
    super.dispose();
  }

  void _startCooldown(int seconds) {
    _timer?.cancel();
    setState(() => _cooldown = seconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      if (_cooldown <= 1) {
        t.cancel();
        setState(() => _cooldown = 0);
      } else {
        setState(() => _cooldown -= 1);
      }
    });
  }

  String get _normalisedMobile {
    final raw = _mobile.text.trim().replaceAll(' ', '');
    if (raw.startsWith('+')) return raw;
    if (raw.length == 10) return '+91$raw';
    return raw;
  }

  Future<void> _sendOtp() async {
    setState(() {
      _error = null;
    });
    if (_normalisedMobile.length < 10) {
      setState(() => _error = 'Enter a valid mobile number.');
      return;
    }
    setState(() => _busy = true);
    try {
      final otp = await widget.auth.sendOtp(_normalisedMobile);
      if (!mounted) return;
      setState(() {
        _otpStage = true;
        _devOtp = otp;
      });
      _startCooldown(30);
      _otpFocus.requestFocus();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        final retry = e.details?['retry_after_seconds'];
        if (retry is num) _startCooldown(retry.toInt());
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verify() async {
    setState(() {
      _error = null;
      _busy = true;
    });
    try {
      await widget.auth.verifyOtp(_code.text);
      // The guest basket follows the shopper into the account.
      await widget.cart?.refresh();
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon: const Icon(Icons.arrow_back_rounded),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding: const EdgeInsets.all(10),
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'Welcome back',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.9,
                  color: AppTheme.ink,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _otpStage
                    ? 'We sent a 6-digit code to $_normalisedMobile'
                    : 'No password needed — we will text you a code.',
                style: const TextStyle(
                  fontSize: 13.5,
                  color: AppTheme.muted,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 28),

              if (!_otpStage) ...[
                const _FieldLabel('Mobile number'),
                TextField(
                  controller: _mobile,
                  keyboardType: TextInputType.phone,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9+]')),
                    LengthLimitingTextInputFormatter(13),
                  ],
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w700),
                  decoration: const InputDecoration(
                    hintText: '+91 98765 00001',
                    prefixIcon: Icon(Icons.phone_iphone_rounded,
                        color: AppTheme.brand),
                  ),
                  onSubmitted: (_) => _sendOtp(),
                ),
              ] else ...[
                const _FieldLabel('Verification code'),
                TextField(
                  controller: _code,
                  focusNode: _otpFocus,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(6),
                  ],
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 12,
                  ),
                  decoration: const InputDecoration(hintText: '••••••'),
                  onSubmitted: (_) => _verify(),
                ),
                if (_devOtp != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppTheme.mint,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: AppTheme.brand.withOpacity(0.25)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.developer_mode_rounded,
                            size: 18, color: AppTheme.brandDark),
                        const SizedBox(width: 8),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                fontSize: 12.5,
                                color: AppTheme.brandDark,
                                fontWeight: FontWeight.w600,
                              ),
                              children: [
                                const TextSpan(text: 'Dev OTP: '),
                                TextSpan(
                                  text: _devOtp,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            _code.text = _devOtp!;
                          },
                          child: const Text(
                            'Use',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],

              if (_error != null) ...[
                const SizedBox(height: 14),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF1F3),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: AppTheme.rose.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline_rounded,
                          size: 18, color: AppTheme.rose),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _error!,
                          style: const TextStyle(
                            color: AppTheme.rose,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _busy
                      ? null
                      : (_otpStage ? _verify : _sendOtp),
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.2,
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          ),
                        )
                      : Text(_otpStage ? 'Verify and continue' : 'Send code'),
                ),
              ),

              if (_otpStage) ...[
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: _cooldown > 0 || _busy
                        ? null
                        : () async {
                            try {
                              final otp = await widget.auth.resendOtp();
                              if (!mounted) return;
                              setState(() => _devOtp = otp);
                              _startCooldown(30);
                            } on ApiException catch (e) {
                              if (!mounted) return;
                              setState(() => _error = e.message);
                            }
                          },
                    child: Text(
                      _cooldown > 0
                          ? 'Resend in ${_cooldown}s'
                          : 'Resend code',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 28),
              Row(
                children: [
                  const Expanded(child: Divider()),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      'Basket is kept when you sign in',
                      style: TextStyle(
                        fontSize: 11,
                        color: AppTheme.muted.withOpacity(0.8),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const Expanded(child: Divider()),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 2),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12.5,
          fontWeight: FontWeight.w800,
          color: AppTheme.ink,
        ),
      ),
    );
  }
}
