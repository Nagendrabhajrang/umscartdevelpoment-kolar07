import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../widgets/common.dart';
import 'login_screen.dart';
import 'order_details_screen.dart';

/// Order history with live status.
///
/// A 25 second poll keeps the list honest: the admin confirming an order shows
/// up here without the shopper pulling to refresh, and the timer stops when the
/// tab is not visible (WidgetsBindingObserver) so a backgrounded app is not
/// making requests all day.
class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key, required this.auth});

  final AuthState auth;

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen>
    with WidgetsBindingObserver {
  List<OrderSummary> _orders = const [];
  bool _loading = true;
  String? _error;
  Timer? _poll;
  String _filter = '';
  bool _visible = true;
  bool _wasSignedIn = false;

  static const _filters = [
    ('', 'All'),
    ('pending', 'Placed'),
    ('confirmed', 'Confirmed'),
    ('out_for_delivery', 'On the way'),
    ('delivered', 'Delivered'),
    ('cancelled', 'Cancelled'),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _wasSignedIn = widget.auth.isSignedIn;
    widget.auth.addListener(_repaint);
    _load();
    _poll = Timer.periodic(const Duration(seconds: 25), (_) {
      if (_visible && widget.auth.isSignedIn) _load(silent: true);
    });
  }

  /// AuthState notifies both on sign-in and on sign-out.
  ///
  /// Repainting alone is not enough: this screen lives inside the shell's
  /// IndexedStack, so it was built (and loaded) while the shopper was signed
  /// out. Without this reload, a fresh sign-in leaves the previous "No orders
  /// yet" snapshot on screen until the 25 s poll happens to fire.
  void _repaint() {
    if (!mounted) return;
    final signedIn = widget.auth.isSignedIn;
    if (signedIn != _wasSignedIn) {
      _wasSignedIn = signedIn;
      setState(() {});
      _load();
      return;
    }
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _visible = state == AppLifecycleState.resumed;
    if (_visible && widget.auth.isSignedIn) _load(silent: true);
  }

  @override
  void dispose() {
    _poll?.cancel();
    widget.auth.removeListener(_repaint);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!widget.auth.isSignedIn) {
      setState(() {
        _loading = false;
        _orders = const [];
      });
      return;
    }
    if (!silent) setState(() => _loading = true);
    try {
      final rows = await OrderService.mine();
      if (!mounted) return;
      setState(() {
        _orders = rows;
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.auth.isSignedIn) {
      return SafeArea(
        child: EmptyView(
          icon: Icons.receipt_long_rounded,
          title: 'Sign in to see your orders',
          message: 'Your order history follows your mobile number.',
          actionLabel: 'Sign in',
          onAction: () async {
            await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => LoginScreen(auth: widget.auth),
              ),
            );
            _load();
          },
        ),
      );
    }

    final rows = _filter.isEmpty
        ? _orders
        : _orders.where((o) => o.status == _filter).toList();

    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'My orders',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.8,
                      color: AppTheme.ink,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => _load(),
                  icon: const Icon(Icons.refresh_rounded),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              itemCount: _filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final (value, label) = _filters[i];
                return AppPill(
                  label: label,
                  selected: _filter == value,
                  onTap: () => setState(() => _filter = value),
                );
              },
            ),
          ),
          Expanded(
            child: _loading
                ? ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 110),
                    itemCount: 4,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, __) => const ShimmerBox(height: 130),
                  )
                : rows.isEmpty
                    ? EmptyView(
                        icon: Icons.receipt_long_rounded,
                        title: _error ?? 'No orders yet',
                        message: _error == null
                            ? 'Once you place an order it will appear here.'
                            : null,
                        actionLabel: _error == null ? 'Shop now' : 'Retry',
                        onAction: _error == null ? _load : _load,
                      )
                    : RefreshIndicator(
                        color: AppTheme.brand,
                        onRefresh: () => _load(),
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(20, 12, 20, 110),
                          itemCount: rows.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 12),
                          itemBuilder: (context, i) => _OrderCard(
                            order: rows[i],
                            onTap: () async {
                              await Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => OrderDetailsScreen(
                                    orderId: rows[i].id,
                                    auth: widget.auth,
                                  ),
                                ),
                              );
                              _load(silent: true);
                            },
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.order, required this.onTap});

  final OrderSummary order;
  final VoidCallback onTap;

  static const _statusColors = {
    'pending': Color(0xFFF59E0B),
    'confirmed': Color(0xFF2563EB),
    'processing': Color(0xFF7C3AED),
    'out_for_delivery': Color(0xFF06B6D4),
    'delivered': Color(0xFF16A34A),
    'cancelled': Color(0xFFE11D48),
  };

  @override
  Widget build(BuildContext context) {
    final color = _statusColors[order.status] ?? AppTheme.muted;
    final first = order.items.isNotEmpty && order.items.first is Map
        ? Map<String, dynamic>.from(order.items.first as Map)
        : <String, dynamic>{};
    // The list endpoint returns counts, not line items, so fall back to a
    // human sentence rather than the bare word "Items".
    final name = first['product_name'] as String? ??
        (order.deliveryCity.isNotEmpty
            ? 'Delivering to ${order.deliveryCity}'
            : 'Order ${order.number}');
    final qty = order.items.length;

    return TiltCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      radius: 20,
      maxTilt: 0.03,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  order.statusLabel,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                    color: color,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                order.number,
                style: const TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.muted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      qty > 1 ? '$name + ${qty - 1} more' : name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.ink,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      [
                        '${order.itemCount} item${order.itemCount == 1 ? '' : 's'}',
                        if (order.paymentLabel.isNotEmpty) order.paymentLabel,
                      ].join(' · '),
                      style: const TextStyle(
                        fontSize: 11.5,
                        color: AppTheme.muted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    money(order.total),
                    style: const TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.ink,
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: AppTheme.muted, size: 18),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
