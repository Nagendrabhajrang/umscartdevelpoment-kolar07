import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/services.dart';
import '../models/models.dart';
import '../state/auth_state.dart';
import '../state/cart_state.dart';
import '../widgets/common.dart';
import 'products_screen.dart';

/// The category browser: a mosaic of gradient tiles, each opening its products.
class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key, required this.auth, required this.cart});

  final AuthState auth;
  final CartState cart;

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  List<Category> _categories = const [];
  bool _loading = true;

  static const _gradients = [
    AppTheme.brandGradient,
    AppTheme.sunsetGradient,
    AppTheme.berryGradient,
    AppTheme.oceanGradient,
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final rows = await CatalogService.categories().catchError((_) => <Category>[]);
    if (!mounted) return;
    setState(() {
      _categories = rows;
      _loading = false;
    });
  }

  void _open(Category c) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ProductsScreen(
        title: c.name,
        categoryId: c.id,
        auth: widget.auth,
        cart: widget.cart,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
            child: Text(
              'Categories',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.8,
                color: AppTheme.ink,
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: Text(
              'Everything the store stocks, grouped',
              style: TextStyle(
                fontSize: 13,
                color: AppTheme.muted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? GridView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 110),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: 1.15,
                    ),
                    itemCount: 6,
                    itemBuilder: (_, __) => const ShimmerBox(height: 130),
                  )
                : RefreshIndicator(
                    color: AppTheme.brand,
                    onRefresh: _load,
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 110),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 1.15,
                      ),
                      itemCount: _categories.length,
                      itemBuilder: (context, i) {
                        final c = _categories[i];
                        return TiltCard(
                          onTap: () => _open(c),
                          padding: EdgeInsets.zero,
                          radius: 22,
                          maxTilt: 0.06,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (c.imageUrl.isNotEmpty)
                                RemoteImage(url: c.imageUrl, radius: 22)
                              else
                                DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient:
                                        _gradients[i % _gradients.length],
                                    borderRadius: BorderRadius.circular(22),
                                  ),
                                ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(22),
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.transparent,
                                      const Color(0xFF04231A)
                                          .withOpacity(0.72),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(14),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      c.name,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                        height: 1.15,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: -0.3,
                                      ),
                                    ),
                                    if (c.productCount > 0)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Text(
                                          '${c.productCount} items',
                                          style: TextStyle(
                                            color: Colors.white
                                                .withOpacity(0.85),
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
