"""Serve the Flutter web build with a same-origin proxy in front of Django.

Why this exists: a browser will not let the app call http://localhost:8000 from
http://localhost:8099 (different origin, and the session cookie is HttpOnly).
Serving the build and proxying /api and /media from one origin keeps the app
same-origin, so cookies and CSRF work exactly as they do on the real device.

    flutter build web --release --dart-define=API_BASE=relative
    python3 serve_web.py            # http://localhost:8099

Android does not need this file: build the APK with the default API_BASE,
which points at 10.0.2.2:8000 from the emulator.
"""

import http.server
import os
import socketserver
import socket
import sys
import urllib.error
import urllib.request

API = os.environ.get("API_UPSTREAM", "http://127.0.0.1:8000")
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build", "web")
PORT = int(os.environ.get("PORT", "8099"))

PROXY_PREFIXES = ("/api/", "/media/")
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
}
# Django rejects an unsafe request whose Origin is not in CSRF_TRUSTED_ORIGINS.
# When the app is opened through a preview/tunnel host that origin is unknown to
# Django, so the proxy rewrites it to the upstream origin. The CSRF *token*
# check is untouched: the token still has to match the cookie.
REWRITE_TO_UPSTREAM = {"origin", "referer"}


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB, **kwargs)

    def _is_proxy(self):
        return self.path.startswith(PROXY_PREFIXES)

    def _proxy(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None

        origin = API.rstrip("/")
        headers = {}
        for key, value in self.headers.items():
            low = key.lower()
            if low in HOP_BY_HOP:
                continue
            if low in REWRITE_TO_UPSTREAM:
                headers[key] = origin if low == "origin" else origin + "/"
                continue
            headers[key] = value
        headers["X-Forwarded-Proto"] = "http"
        headers["X-Forwarded-Host"] = self.headers.get("Host", "")

        req = urllib.request.Request(
            API + self.path, data=body, headers=headers, method=self.command
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as upstream:
                self._relay(upstream.status, upstream.headers, upstream.read())
        except urllib.error.HTTPError as exc:
            self._relay(exc.code, exc.headers, exc.read())
        except Exception as exc:  # upstream down, DNS failure, timeout
            payload = f'{{"error":{{"code":"upstream_unreachable","message":"{exc}"}}}}'
            self._relay(502, {}, payload.encode())

    def _relay(self, status, headers, payload):
        self.send_response(status)
        for key, value in (headers.items() if headers else []):
            if key.lower() not in HOP_BY_HOP:
                self.send_header(key, value)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(payload)

    def do_GET(self):
        if self._is_proxy():
            return self._proxy()
        return super().do_GET()

    def do_HEAD(self):
        if self._is_proxy():
            return self._proxy()
        return super().do_HEAD()

    def do_POST(self):
        return self._proxy()

    def do_PUT(self):
        return self._proxy()

    def do_PATCH(self):
        return self._proxy()

    def do_DELETE(self):
        return self._proxy()

    def do_OPTIONS(self):
        return self._proxy()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    if not os.path.isdir(WEB):
        sys.exit("No build/web — run: flutter build web --release --dart-define=API_BASE=relative")
    host = "0.0.0.0"
    try:
        with socket.create_connection(("127.0.0.1", 8000), timeout=2):
            print(f"API upstream {API} is reachable.")
    except OSError:
        print(f"WARNING: {API} is not answering — start Django first.", file=sys.stderr)
    print(f"Flutter customer app on http://localhost:{PORT}  (proxy: /api, /media -> {API})")
    with Server((host, PORT), Handler) as httpd:
        httpd.serve_forever()
